# Known MSVC / Win32 compile-hazard regression gate.
# This does not replace the real MSVC build; it prevents reintroducing defects that
# were already observed on the authoritative Windows verifier.
set(_such_win_src "${CMAKE_CURRENT_LIST_DIR}/../platform/windows/Win32Frontend.cpp")
set(_such_test_src "${CMAKE_CURRENT_LIST_DIR}/../tests/test_v061_frontend.cpp")

foreach(_required "${_such_win_src}" "${_such_test_src}")
  if(NOT EXISTS "${_required}")
    message(FATAL_ERROR "Windows compile-hazard gate missing required file: ${_required}")
  endif()
endforeach()

file(READ "${_such_win_src}" _such_win_text)
file(READ "${_such_test_src}" _such_test_text)

foreach(_forbidden
    "SIID_FAVORITES"
    "SetPointerCapture("
    "ReleasePointerCapture("
    "std::max(1, client.right"
    "std::max(1, client.bottom"
    "std::min(end, row.left"
    "std::max(start, row.right")
  string(FIND "${_such_win_text}" "${_forbidden}" _hit)
  if(NOT _hit EQUAL -1)
    message(FATAL_ERROR "Rejected known Win32/MSVC compile hazard '${_forbidden}'")
  endif()
endforeach()

string(FIND "${_such_test_text}" "CHECK(design::k" _runtime_const_check)
if(NOT _runtime_const_check EQUAL -1)
  message(FATAL_ERROR "Compile-time DesignContract constants must use static_assert, not runtime CHECK on MSVC /WX")
endif()

string(FIND "${_such_test_text}" "while (false)" _constant_loop)
if(NOT _constant_loop EQUAL -1)
  message(FATAL_ERROR "Rejected constant-condition test macro pattern that previously triggered MSVC C4127/C2220")
endif()

message(STATUS "Such Win32/MSVC known-hazard gate: PASS")
