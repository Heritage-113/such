# Such

Such is a native local-file search frontend by Heritage Inc.

This public repository contains the native UI, CLI, stable runtime ABI/client, installers, and public contracts. The search/storage implementation is deliberately outside this repository. At runtime, Such loads a separately distributed `SuchRuntimePrivate` shared library through the stable C ABI in `include/such/runtime/RuntimeABI.h`.

## Build

See `scripts/BUILDING.md`.

## Search scope commands

- Windows: `/index`, `/drive`, `/reindex`, `/roots`, `/font`
- macOS/Linux/iPadOS: `//index`, `//drive`, `//reindex`, `//roots`, `//font`

`/index` adds a search root. `/drive` replaces the complete search-root set.
