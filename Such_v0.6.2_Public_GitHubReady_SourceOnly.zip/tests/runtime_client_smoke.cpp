#include <such/runtime/RuntimeClient.h>
#include <filesystem>
#include <iostream>

int main() {
    such::runtime::RuntimeClient runtime;
    std::string error;
    if (!runtime.load(&error)) { std::cerr << error << '\n'; return 1; }
    if (!runtime.add_root(std::filesystem::path("/stub"), &error)) return 2;
    const auto rows = runtime.search("report", such::ui::PlatformDialect::UnixLike, 25);
    if (rows.size() != 1 || rows.front().filename != "project_report.pdf") return 3;
    const auto status = runtime.status();
    if (status.indexed_files != 1 || runtime.observed_extensions().empty()) return 4;
    const auto stats = runtime.engine_stats();
    if (!stats.backend_active) return 5;
    std::cout << "runtime client ABI smoke PASS\n";
    return 0;
}
