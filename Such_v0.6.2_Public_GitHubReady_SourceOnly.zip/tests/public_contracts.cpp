#include <such/ui/IndexCommands.h>
#include <such/ui/SearchDialect.h>
#include <cstdlib>
#include <iostream>

int main() {
    using namespace such::ui;
    const auto w = parse_index_command("/drive X:\\Work", PlatformDialect::Windows);
    if (!w.matched || w.kind != IndexCommandKind::ReplaceRoot || !w.argument.has_value()) return 1;
    const auto u = parse_index_command("//drive /srv/work", PlatformDialect::UnixLike);
    if (!u.matched || u.kind != IndexCommandKind::ReplaceRoot || !u.argument.has_value()) return 2;
    const auto filter = parse_search_query("/pdf /week report", PlatformDialect::Windows, 1'800'000'000);
    if (filter.extensions.empty() || filter.text != "report") return 3;
    std::cout << "public contracts PASS\n";
    return 0;
}
