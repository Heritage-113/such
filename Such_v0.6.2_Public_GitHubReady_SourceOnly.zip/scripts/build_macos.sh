#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD_DIR="${BUILD_DIR:-$ROOT/build/v0.6.2/public-macos-release}"
[[ "${1:-}" == "--clean" ]] && rm -rf "$BUILD_DIR"
cmake -S "$ROOT" -B "$BUILD_DIR" -DCMAKE_BUILD_TYPE=Release -DSUCH_BUILD_GUI=ON -DSUCH_BUILD_CLI=ON -DSUCH_BUILD_TESTS=ON -DSUCH_STRICT_WARNINGS=ON
cmake --build "$BUILD_DIR" --parallel "${JOBS:-4}"
ctest --test-dir "$BUILD_DIR" --output-on-failure
