[CmdletBinding()]
param(
  [ValidateSet('Debug','Release','RelWithDebInfo','MinSizeRel')][string]$Config='Release',
  [ValidateSet('x64','Win32','ARM64')][string]$Arch='x64',
  [string]$Generator='Visual Studio 17 2022',
  [ValidateRange(1,64)][int]$Jobs=1,
  [switch]$Clean
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'windows_paths.ps1')
$params=@{Config=$Config;Arch=$Arch;Generator=$Generator;Jobs=$Jobs}
if ($Clean.IsPresent) { $params.Clean=$true }
& (Join-Path $PSScriptRoot 'build_windows.ps1') @params
$Root=Get-SuchSourceRoot -ScriptRoot $PSScriptRoot
$Ws=Get-SuchWindowsWorkspace -SourceRoot $Root -Arch $Arch -Config $Config
$bin=Join-Path $Ws.BuildDir $Config
$stub=Join-Path $bin 'SuchRuntimeStub.dll'
$gui=Join-Path $bin 'Such.exe'
$cli=Join-Path $bin 'SuchCLI.exe'
foreach ($p in @($stub,$gui,$cli)) { if (-not (Test-Path -LiteralPath $p)) { throw "Missing build output: $p" } }
$old=$env:SUCH_RUNTIME_LIBRARY
try {
  $env:SUCH_RUNTIME_LIBRARY=$stub
  & $cli 'report'
  if ($LASTEXITCODE -ne 0) { throw "CLI ABI stub smoke failed with exit $LASTEXITCODE" }
  & $gui '--smoke'
  if ($LASTEXITCODE -ne 0) { throw "GUI ABI stub smoke failed with exit $LASTEXITCODE" }
} finally { $env:SUCH_RUNTIME_LIBRARY=$old }
Write-Host 'Public Windows verification PASS'
