#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
"$ROOT/scripts/build_linux.sh" "$@"
CONFIG="${CONFIG:-Release}"
CONFIG_LOWER="$(printf '%s' "$CONFIG" | tr '[:upper:]' '[:lower:]')"
BUILD_DIR="${BUILD_DIR:-$ROOT/build/v0.6.2/public-linux-$CONFIG_LOWER}"
if command -v xvfb-run >/dev/null 2>&1; then
  SUCH_RUNTIME_LIBRARY="$BUILD_DIR/libSuchRuntimeStub.so" xvfb-run -a "$BUILD_DIR/such" --smoke >/dev/null 2>&1 || {
    echo 'X11 public smoke failed' >&2; exit 7;
  }
fi
printf 'Public Linux verification PASS\n'
