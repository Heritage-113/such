[CmdletBinding()]
param(
  [ValidateSet('Debug','Release','RelWithDebInfo','MinSizeRel')][string]$Config='Release',
  [ValidateSet('x64','Win32','ARM64')][string]$Arch='x64',
  [string]$Generator='Visual Studio 17 2022',
  [ValidateRange(1,64)][int]$Jobs=1,
  [switch]$Clean
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'windows_paths.ps1')
$Root=Get-SuchSourceRoot -ScriptRoot $PSScriptRoot
& (Join-Path $PSScriptRoot 'audit_windows.ps1')
python (Join-Path $PSScriptRoot 'audit_repository_layout.py')
if ($LASTEXITCODE -ne 0) { throw 'public repository layout audit failed' }
$Ws=Get-SuchWindowsWorkspace -SourceRoot $Root -Arch $Arch -Config $Config
Write-SuchPathDiagnostics -Workspace $Ws
if ($Clean.IsPresent) { Remove-Item -LiteralPath $Ws.BuildDir,$Ws.InstallDir -Recurse -Force -ErrorAction SilentlyContinue }
$cmakeArgs=@('-S',$Ws.CMakeSource,'-B',$Ws.BuildDir,'-G',$Generator,'-A',$Arch,'-DSUCH_BUILD_GUI=ON','-DSUCH_BUILD_CLI=ON','-DSUCH_BUILD_TESTS=ON','-DSUCH_STRICT_WARNINGS=ON')
& cmake @cmakeArgs
if ($LASTEXITCODE -ne 0) { throw "CMake configure failed with exit $LASTEXITCODE" }
& cmake --build $Ws.BuildDir --config $Config --parallel $Jobs
if ($LASTEXITCODE -ne 0) { throw "CMake build failed with exit $LASTEXITCODE" }
& ctest --test-dir $Ws.BuildDir -C $Config --output-on-failure
if ($LASTEXITCODE -ne 0) { throw "CTest failed with exit $LASTEXITCODE" }
& cmake --install $Ws.BuildDir --config $Config --prefix $Ws.InstallDir
if ($LASTEXITCODE -ne 0) { throw "Install staging failed with exit $LASTEXITCODE" }
Write-Host "Public Windows build complete: $($Ws.BuildDir)"
