[CmdletBinding()]
param(
  [string]$SourceRoot
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

if ([string]::IsNullOrWhiteSpace($SourceRoot)) {
  $SourceRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
} else {
  $SourceRoot = [System.IO.Path]::GetFullPath($SourceRoot)
}

function Fail-Audit {
  param([string]$Message)
  throw "Windows source audit failed: $Message"
}

# Parse every PowerShell build/verification script with PowerShell's own parser.
$psFiles = Get-ChildItem -LiteralPath (Join-Path $SourceRoot 'scripts') -Filter '*.ps1' -File
foreach ($file in $psFiles) {
  $tokens = $null
  $errors = $null
  [void][System.Management.Automation.Language.Parser]::ParseFile(
    $file.FullName,
    [ref]$tokens,
    [ref]$errors)
  if (@($errors).Count -ne 0) {
    $details = ($errors | ForEach-Object { "line $($_.Extent.StartLineNumber): $($_.Message)" }) -join '; '
    Fail-Audit "$($file.Name): $details"
  }
}

$winPath = Join-Path $SourceRoot 'platform/windows/Win32Frontend.cpp'
$testPath = Join-Path $SourceRoot 'tests/test_v061_frontend.cpp'
$cmakePath = Join-Path $SourceRoot 'CMakeLists.txt'
foreach ($required in @($winPath, $testPath, $cmakePath)) {
  if (-not (Test-Path -LiteralPath $required)) { Fail-Audit "missing required file: $required" }
}

$win = Get-Content -LiteralPath $winPath -Raw
$tests = Get-Content -LiteralPath $testPath -Raw
$cmake = Get-Content -LiteralPath $cmakePath -Raw

$forbidden = @(
  @{ Text = $win; Pattern = '\bSIID_FAVORITES\b'; Why = 'SIID_FAVORITES is not a valid SHSTOCKICONID.' },
  @{ Text = $win; Pattern = '\b(?:SetPointerCapture|ReleasePointerCapture)\b'; Why = 'Classic HWND WM_POINTER input uses implicit capture; these calls are not Win32 APIs used by this frontend.' },
  @{ Text = $win; Pattern = 'std::(?:max|min)\s*\(\s*(?:client|row|search|suggested)\.(?:left|right|top|bottom)'; Why = 'Normalize RECT/LONG geometry to int before STL min/max.' },
  @{ Text = $win; Pattern = 'std::(?:max|min)\s*\(\s*[^,\r\n]+,\s*(?:client|row|search|suggested)\.(?:left|right|top|bottom)'; Why = 'Normalize RECT/LONG geometry to int before STL min/max.' },
  @{ Text = $tests; Pattern = '#define\s+CHECK[^\r\n]*do\s*\{'; Why = 'MSVC /W4 /WX can turn constant-condition CHECK macro control flow into C4127/C2220.' },
  @{ Text = $tests; Pattern = 'CHECK\s*\(\s*design::k'; Why = 'Compile-time design invariants must use static_assert, not runtime CHECK.' },
  @{ Text = ($win + "`n" + $tests + "`n" + $cmake); Pattern = '\bsuch_v038\b'; Why = 'Active v0.6.2 sources must not regress target names to v0.3.8.' }
)
foreach ($rule in $forbidden) {
  if ([regex]::IsMatch($rule.Text, $rule.Pattern, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
    Fail-Audit $rule.Why
  }
}

# Keep the already-fixed MoveWindow call in its full six-argument Win32 form.
if ($win -notmatch 'MoveWindow\s*\(\s*gSearch\s*,\s*searchX\s*,\s*searchY\s*,\s*searchW\s*,\s*searchH\s*,\s*TRUE\s*\)') {
  Fail-Audit 'Expected six-argument MoveWindow(gSearch, searchX, searchY, searchW, searchH, TRUE) call not found.'
}

# The Windows target must remain /W4 /WX strict; do not hide compiler errors with blanket disables.
if ($cmake -notmatch '/W4' -or $cmake -notmatch '/WX') {
  Fail-Audit 'MSVC strict warning policy (/W4 and /WX) is missing.'
}
if ($cmake -match '/wd4127') {
  Fail-Audit 'C4127 must be fixed in source, not globally suppressed.'
}

Write-Host 'Windows source audit PASS: PowerShell syntax + MSVC hazard patterns checked.'
