Set-StrictMode -Version Latest

function Get-SuchSourceRoot {
    param([Parameter(Mandatory=$true)][string]$ScriptRoot)
    # Avoid Resolve-Path wildcard semantics. Preserve literal paths such as [] and #.
    return [System.IO.Path]::GetFullPath((Join-Path $ScriptRoot '..'))
}

function Get-SuchWindowsWorkspace {
    param(
        [Parameter(Mandatory=$true)][string]$SourceRoot,
        [Parameter(Mandatory=$true)][string]$Arch,
        [Parameter(Mandatory=$true)][string]$Config
    )

    $base = $env:SUCH_BUILD_ROOT
    if ([string]::IsNullOrWhiteSpace($base)) {
        if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA)) {
            $base = Join-Path ([System.IO.Path]::GetTempPath()) 'SuchBuild'
        } else {
            $base = Join-Path $env:LOCALAPPDATA 'SuchBuild'
        }
    }
    $base = [System.IO.Path]::GetFullPath($base)

    $versionRoot = Join-Path $base 'v062'
    $buildDir = Join-Path $versionRoot ("b-{0}-{1}" -f $Arch.ToLowerInvariant(), $Config.ToLowerInvariant())
    $installDir = Join-Path $versionRoot ("i-{0}-{1}" -f $Arch.ToLowerInvariant(), $Config.ToLowerInvariant())
    $consumerDir = Join-Path $versionRoot ("c-{0}-{1}" -f $Arch.ToLowerInvariant(), $Config.ToLowerInvariant())
    $sourceLink = Join-Path $versionRoot 'src'

    New-Item -ItemType Directory -Force -Path $versionRoot | Out-Null

    # Use a short junction for the CMake source root where possible. This keeps
    # Visual Studio .vcxproj, .obj, depfile and generated command paths short even
    # when the user extracted the archive into a deeply nested directory.
    $cmakeSource = $SourceRoot
    try {
        if (Test-Path -LiteralPath $sourceLink) {
            $item = Get-Item -LiteralPath $sourceLink -Force
            $mustReplace = $true
            if ($item.LinkType -eq 'Junction' -or $item.LinkType -eq 'SymbolicLink') {
                $target = @($item.Target)[0]
                if ($target) {
                    $resolvedTarget = [System.IO.Path]::GetFullPath($target)
                    $resolvedSource = [System.IO.Path]::GetFullPath($SourceRoot)
                    if ([System.StringComparer]::OrdinalIgnoreCase.Equals($resolvedTarget.TrimEnd('\\'), $resolvedSource.TrimEnd('\\'))) {
                        $mustReplace = $false
                    }
                }
            }
            if ($mustReplace) {
                    # Remove only the reparse-point entry. Never recurse through a junction
                    # into the user's source tree. cmd /c rmdir has stable junction semantics
                    # across Windows PowerShell 5.1 and PowerShell 7.
                    & cmd.exe /d /c rmdir "$sourceLink" | Out-Null
                    if ($LASTEXITCODE -ne 0 -and (Test-Path -LiteralPath $sourceLink)) {
                        throw "Could not remove stale source junction: $sourceLink"
                    }
                }
        }
        if (-not (Test-Path -LiteralPath $sourceLink)) {
            New-Item -ItemType Junction -Path $sourceLink -Target $SourceRoot -ErrorAction Stop | Out-Null
        }
        $cmakeSource = $sourceLink
    }
    catch {
        Write-Warning "Could not create short source junction '$sourceLink': $($_.Exception.Message)"
        Write-Warning "Falling back to original source path. If MSVC still reports path errors, move/extract the source to a short path such as X:\\Such\\v062."
    }

    return [pscustomobject]@{
        SourceRoot = $SourceRoot
        CMakeSource = $cmakeSource
        Base = $base
        VersionRoot = $versionRoot
        BuildDir = $buildDir
        InstallDir = $installDir
        ConsumerDir = $consumerDir
        SourceLink = $sourceLink
    }
}

function Write-SuchPathDiagnostics {
    param([Parameter(Mandatory=$true)]$Workspace)
    Write-Host ('Source root     : {0} ({1} chars)' -f $Workspace.SourceRoot, $Workspace.SourceRoot.Length)
    Write-Host ('CMake -S        : {0} ({1} chars)' -f $Workspace.CMakeSource, $Workspace.CMakeSource.Length)
    Write-Host ('Build directory : {0} ({1} chars)' -f $Workspace.BuildDir, $Workspace.BuildDir.Length)
    Write-Host ('Install dir     : {0} ({1} chars)' -f $Workspace.InstallDir, $Workspace.InstallDir.Length)
    if ($Workspace.SourceRoot.Length -gt 100) {
        Write-Warning 'The original source path is long. The short source junction above is intentionally used for CMake/MSVC.'
    }
}
