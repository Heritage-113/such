#!/usr/bin/env bash
set -euo pipefail
"$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/build_macos.sh" "$@"
printf 'Public macOS build verification PASS\n'
