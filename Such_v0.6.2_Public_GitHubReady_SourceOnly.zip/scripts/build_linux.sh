#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG="${CONFIG:-Release}"
CONFIG_LOWER="$(printf '%s' "$CONFIG" | tr '[:upper:]' '[:lower:]')"
BUILD_DIR="${BUILD_DIR:-$ROOT/build/v0.6.2/public-linux-$CONFIG_LOWER}"
INSTALL_DIR="${INSTALL_DIR:-$ROOT/dist/v0.6.2/public-linux-$CONFIG_LOWER}"
JOBS="${JOBS:-$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 4)}"
CLEAN=0
for arg in "$@"; do
  case "$arg" in
    --clean) CLEAN=1 ;;
    *) echo "Unknown option: $arg" >&2; exit 2 ;;
  esac
done
command -v cmake >/dev/null || { echo 'cmake not found' >&2; exit 2; }
command -v ctest >/dev/null || { echo 'ctest not found' >&2; exit 2; }
python3 "$ROOT/scripts/audit_repository_layout.py"
if [[ "$CLEAN" == 1 ]]; then rm -rf "$BUILD_DIR" "$INSTALL_DIR"; fi
cmake -S "$ROOT" -B "$BUILD_DIR" \
  -DCMAKE_BUILD_TYPE="$CONFIG" \
  -DSUCH_BUILD_GUI=ON -DSUCH_BUILD_CLI=ON -DSUCH_BUILD_TESTS=ON \
  -DSUCH_STRICT_WARNINGS=ON
cmake --build "$BUILD_DIR" --parallel "$JOBS"
ctest --test-dir "$BUILD_DIR" --output-on-failure
cmake --install "$BUILD_DIR" --prefix "$INSTALL_DIR"
printf 'Public Linux build complete: %s\n' "$BUILD_DIR"
printf 'Public install staging: %s\n' "$INSTALL_DIR"
