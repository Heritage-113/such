#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
allowed = {'.github','.gitignore','CMakeLists.txt','LICENSE','README.md','apps','assets','cmake','docs','font-bundles','include','platform','scripts','src','tests','build','dist','BUILD_VALIDATION_v0.6.2.md','PACKAGE_MANIFEST.txt'}
bad = []
for child in root.iterdir():
    if child.name not in allowed:
        bad.append(child.name)
for p in root.rglob('*'):
    if p.is_symlink():
        bad.append(f'symlink:{p.relative_to(root)}')
if bad:
    print('Public repository layout rejected:')
    for item in sorted(set(bad)): print('  ', item)
    sys.exit(2)
print('public repository layout PASS')
