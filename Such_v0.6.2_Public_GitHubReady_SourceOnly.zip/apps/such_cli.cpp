#include <such/runtime/RuntimeClient.h>
#include <such/ui/FrontendLease.h>
#include <such/ui/FontSettings.h>
#include <such/ui/IndexCommands.h>
#include <such/ui/SearchDialect.h>

#include <charconv>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <string>
#include <thread>

namespace {

bool parse_nonnegative_int(const char* text, int& out) noexcept {
    if (!text || !*text) return false;
    int value = 0;
    const char* end = text + std::strlen(text);
    const auto result = std::from_chars(text, end, value);
    if (result.ec != std::errc{} || result.ptr != end || value < 0) return false;
    out = value;
    return true;
}

} // namespace

int main(int argc, char** argv) {
    auto lease = such::ui::FrontendLease::try_acquire(such::ui::FrontendMode::Cli);
    if (!lease.acquired()) {
        std::fprintf(stderr, "Such is already running in another frontend mode. Close it before starting the CLI.\n");
        return 23;
    }

    int hold_ms = 0;
    std::string query;
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--hold-ms") == 0) {
            if (i + 1 >= argc || !parse_nonnegative_int(argv[i + 1], hold_ms)) {
                std::fprintf(stderr, "Invalid --hold-ms value.\n");
                return 2;
            }
            ++i;
            if (hold_ms > 60'000) hold_ms = 60'000;
        } else {
            if (!query.empty()) query.push_back(' ');
            query += argv[i];
        }
    }
    if (hold_ms > 0) std::this_thread::sleep_for(std::chrono::milliseconds(hold_ms));

#if defined(_WIN32)
    constexpr auto dialect = such::ui::PlatformDialect::Windows;
#else
    constexpr auto dialect = such::ui::PlatformDialect::UnixLike;
#endif

    if (const auto font = such::ui::parse_font_command(query, dialect); font.matched) {
        if (font.show_picker) {
            std::printf("font settings:\n");
            for (const auto& option : such::ui::builtin_font_options()) {
                std::printf("  %sfont %s -> %s\n", std::string(such::ui::operator_prefix(dialect)).c_str(), option.alias.c_str(), option.family.c_str());
            }
            std::printf("  %sfont system -> system default\n", std::string(such::ui::operator_prefix(dialect)).c_str());
            return 0;
        }
        if (font.requested_family.has_value()) {
            std::string error;
            const bool ok = font.requested_family->empty()
                ? such::ui::clear_font_preference(&error)
                : such::ui::save_font_preference(*font.requested_family, &error);
            if (!ok) { std::fprintf(stderr, "font setting failed: %s\n", error.c_str()); return 4; }
            std::printf("font=%s\n", font.requested_family->empty() ? "system" : font.requested_family->c_str());
            return 0;
        }
    }

    such::runtime::RuntimeClient runtime;
    std::string runtime_error;
    if (!runtime.load(&runtime_error)) {
        std::fprintf(stderr, "Such index load failed: %s\n", runtime_error.c_str());
        return 5;
    }

    if (const auto command = such::ui::parse_index_command(query, dialect); command.matched) {
        switch (command.kind) {
            case such::ui::IndexCommandKind::AddRoot:
                if (!command.argument.has_value()) {
                    std::fprintf(stderr, "CLI index usage: %sindex <folder>\n", std::string(such::ui::operator_prefix(dialect)).c_str());
                    return 2;
                }
                if (!runtime.add_root(*command.argument, &runtime_error)) {
                    std::fprintf(stderr, "index root failed: %s\n", runtime_error.c_str());
                    return 6;
                }
                runtime.wait_for_idle();
                std::printf("indexed_files=%zu\n", runtime.status().indexed_files);
                return 0;
            case such::ui::IndexCommandKind::ReplaceRoot:
                if (!command.argument.has_value()) {
                    std::fprintf(stderr, "CLI drive usage: %sdrive <folder>\n", std::string(such::ui::operator_prefix(dialect)).c_str());
                    return 2;
                }
                if (!runtime.replace_roots({std::filesystem::path(*command.argument)}, &runtime_error)) {
                    std::fprintf(stderr, "replace search root failed: %s\n", runtime_error.c_str());
                    return 6;
                }
                runtime.wait_for_idle();
                std::printf("indexed_files=%zu\n", runtime.status().indexed_files);
                return 0;
            case such::ui::IndexCommandKind::Reindex:
                runtime.reindex_async();
                runtime.wait_for_idle();
                std::printf("indexed_files=%zu\n", runtime.status().indexed_files);
                return 0;
            case such::ui::IndexCommandKind::ShowRoots:
                for (const auto& root : runtime.roots()) std::printf("%s\n", root.c_str());
                return 0;
            case such::ui::IndexCommandKind::NoCommand:
                break;
        }
    }

    const auto results = runtime.search(query, dialect);
    for (const auto& item : results) {
        std::printf("%s\t%s%s\n", item.filename.c_str(), item.path.c_str(), item.pinned ? "\tPIN" : "");
    }
    return 0;
}
