#include <such/ui/FrontendLease.h>

#if defined(_WIN32)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#else
#include <cerrno>
#include <cstdlib>
#include <fcntl.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <unistd.h>
#endif

#include <utility>

namespace such::ui {

FrontendLease::FrontendLease(FrontendLease&& other) noexcept { *this = std::move(other); }
FrontendLease& FrontendLease::operator=(FrontendLease&& other) noexcept {
    if (this == &other) return *this;
    release();
    mode_ = other.mode_;
    acquired_ = other.acquired_;
    error_ = std::move(other.error_);
#if defined(_WIN32)
    handle_ = other.handle_; other.handle_ = nullptr;
#else
    fd_ = other.fd_; other.fd_ = -1;
#endif
    other.acquired_ = false;
    return *this;
}
FrontendLease::~FrontendLease() { release(); }

FrontendLease FrontendLease::try_acquire(FrontendMode mode) {
    FrontendLease lease;
    lease.mode_ = mode;
#if defined(_WIN32)
    HANDLE h = CreateMutexW(nullptr, FALSE, L"Local\\Heritage.Such.Frontend");
    if (!h) { lease.error_ = "CreateMutexW failed"; return lease; }
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        CloseHandle(h);
        lease.error_ = "another Such frontend is already running";
        return lease;
    }
    lease.handle_ = h;
    lease.acquired_ = true;
#else
    const char* runtime = std::getenv("XDG_RUNTIME_DIR");
    std::string path;
    if (runtime && *runtime && ::access(runtime, W_OK | X_OK) == 0) {
        path = std::string(runtime) + "/heritage-such-frontend.lock";
    } else {
        path = "/tmp/heritage-such-frontend-" + std::to_string(static_cast<long long>(::getuid())) + ".lock";
    }
    const int fd = ::open(path.c_str(), O_CREAT | O_RDWR | O_CLOEXEC, 0600);
    if (fd < 0) { lease.error_ = "open frontend lock failed"; return lease; }
    if (::flock(fd, LOCK_EX | LOCK_NB) != 0) {
        const int lock_errno = errno;
        ::close(fd);
        lease.error_ = (lock_errno == EWOULDBLOCK || lock_errno == EAGAIN)
            ? "another Such frontend is already running"
            : "flock frontend lock failed";
        return lease;
    }
    lease.fd_ = fd;
    lease.acquired_ = true;
#endif
    return lease;
}

void FrontendLease::release() noexcept {
    if (!acquired_) return;
#if defined(_WIN32)
    if (handle_) CloseHandle(static_cast<HANDLE>(handle_));
    handle_ = nullptr;
#else
    if (fd_ >= 0) { ::flock(fd_, LOCK_UN); ::close(fd_); }
    fd_ = -1;
#endif
    acquired_ = false;
}

} // namespace such::ui
