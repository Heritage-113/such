#include <such/ui/SearchDialect.h>

#include <algorithm>
#include <array>
#include <charconv>
#include <cctype>
#include <ctime>
#include <sstream>
#include <unordered_set>

namespace such::ui {
namespace {

constexpr std::int64_t kDay = 86400;

constexpr std::array<std::string_view, 33> kBuiltInExtensions{{
    "pdf", "dwg", "dxf", "3dm", "rvt", "ifc", "skp", "ai", "svg", "psd",
    "png", "jpg", "jpeg", "tif", "tiff", "txt", "md", "doc", "docx", "xls",
    "xlsx", "ppt", "pptx", "csv", "cpp", "c", "h", "hpp", "rs", "py", "go",
    "cs", "json"
}};

std::string lower_ascii(std::string_view v) {
    std::string out(v);
    std::transform(out.begin(), out.end(), out.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return out;
}

bool all_digits(std::string_view v) {
    return !v.empty() && std::all_of(v.begin(), v.end(), [](unsigned char c) {
        return std::isdigit(c) != 0;
    });
}

bool localtime_safe(std::time_t value, std::tm& out) noexcept {
#if defined(_WIN32)
    return ::localtime_s(&out, &value) == 0;
#else
    return ::localtime_r(&value, &out) != nullptr;
#endif
}

std::optional<std::int64_t> local_epoch_for_ymd(int y, int m, int d) {
    if (y < 1970 || y > 9999 || m < 1 || m > 12 || d < 1 || d > 31) return std::nullopt;
    std::tm tm{};
    tm.tm_year = y - 1900;
    tm.tm_mon = m - 1;
    tm.tm_mday = d;
    tm.tm_hour = 0;
    tm.tm_min = 0;
    tm.tm_sec = 0;
    tm.tm_isdst = -1;
    const std::time_t epoch = std::mktime(&tm);
    if (epoch == static_cast<std::time_t>(-1)) return std::nullopt;

    // mktime normalizes invalid dates (e.g. February 31). Round-trip to reject
    // such tokens instead of silently consuming them as valid filters.
    std::tm check{};
    if (!localtime_safe(epoch, check)) return std::nullopt;
    if (check.tm_year != y - 1900 || check.tm_mon != m - 1 || check.tm_mday != d) return std::nullopt;
    return static_cast<std::int64_t>(epoch);
}

std::optional<std::int64_t> parse_iso_day_local(std::string_view s) {
    if (s.size() != 10 || s[4] != '-' || s[7] != '-') return std::nullopt;
    const auto ys = s.substr(0, 4);
    const auto ms = s.substr(5, 2);
    const auto ds = s.substr(8, 2);
    if (!all_digits(ys) || !all_digits(ms) || !all_digits(ds)) return std::nullopt;
    int y = 0;
    int m = 0;
    int d = 0;
    const auto yr = std::from_chars(ys.data(), ys.data() + ys.size(), y);
    const auto mr = std::from_chars(ms.data(), ms.data() + ms.size(), m);
    const auto dr = std::from_chars(ds.data(), ds.data() + ds.size(), d);
    if (yr.ec != std::errc{} || mr.ec != std::errc{} || dr.ec != std::errc{}) return std::nullopt;
    return local_epoch_for_ymd(y, m, d);
}

std::optional<std::pair<std::int64_t, std::int64_t>> parse_iso_month_local(std::string_view s) {
    if (s.size() != 7 || s[4] != '-') return std::nullopt;
    const auto ys = s.substr(0, 4);
    const auto ms = s.substr(5, 2);
    if (!all_digits(ys) || !all_digits(ms)) return std::nullopt;
    int y = 0;
    int m = 0;
    const auto yr = std::from_chars(ys.data(), ys.data() + ys.size(), y);
    const auto mr = std::from_chars(ms.data(), ms.data() + ms.size(), m);
    if (yr.ec != std::errc{} || mr.ec != std::errc{} || m < 1 || m > 12) return std::nullopt;
    const auto begin = local_epoch_for_ymd(y, m, 1);
    const int next_y = m == 12 ? y + 1 : y;
    const int next_m = m == 12 ? 1 : m + 1;
    const auto end = local_epoch_for_ymd(next_y, next_m, 1);
    if (!begin || !end) return std::nullopt;
    return std::pair<std::int64_t, std::int64_t>{*begin, *end};
}

std::optional<std::pair<std::int64_t, std::int64_t>> local_day_range(std::int64_t now, int day_delta) {
    const std::time_t current = static_cast<std::time_t>(now);
    std::tm tm{};
    if (!localtime_safe(current, tm)) return std::nullopt;
    tm.tm_mday += day_delta;
    tm.tm_hour = 0;
    tm.tm_min = 0;
    tm.tm_sec = 0;
    tm.tm_isdst = -1;
    const std::time_t begin = std::mktime(&tm);
    if (begin == static_cast<std::time_t>(-1)) return std::nullopt;
    tm.tm_mday += 1;
    tm.tm_isdst = -1;
    const std::time_t end = std::mktime(&tm);
    if (end == static_cast<std::time_t>(-1)) return std::nullopt;
    return std::pair<std::int64_t, std::int64_t>{
        static_cast<std::int64_t>(begin), static_cast<std::int64_t>(end)};
}

bool looks_extension(std::string_view body) {
    if (body.empty() || body.size() > 16 || body.find(':') != std::string_view::npos) return false;
    return std::all_of(body.begin(), body.end(), [](unsigned char c) {
        return std::isalnum(c) != 0 || c == '_' || c == '-' || c == '+';
    });
}

std::unordered_set<std::string> extension_registry(const std::vector<std::string>& observed_extensions) {
    std::unordered_set<std::string> out;
    out.reserve(kBuiltInExtensions.size() + observed_extensions.size());
    for (const auto ext : kBuiltInExtensions) out.emplace(ext);
    for (const auto& ext0 : observed_extensions) {
        std::string ext = lower_ascii(ext0);
        if (!ext.empty() && ext.front() == '.') ext.erase(ext.begin());
        if (looks_extension(ext)) out.insert(std::move(ext));
    }
    return out;
}

bool is_valid_control(std::string_view body) {
    const std::string v = lower_ascii(body);
    if (v == "pin" || v == "today" || v == "yesterday" || v == "week" || v == "month" || v == "year") {
        return true;
    }
    if (v.starts_with("date:")) return parse_iso_day_local(std::string_view(v).substr(5)).has_value();
    if (v.starts_with("after:")) return parse_iso_day_local(std::string_view(v).substr(6)).has_value();
    if (v.starts_with("before:")) return parse_iso_day_local(std::string_view(v).substr(7)).has_value();
    return parse_iso_day_local(v).has_value() || parse_iso_month_local(v).has_value();
}

void apply_date_token(SearchFilter& out, std::string_view body, std::int64_t now) {
    const std::string v = lower_ascii(body);
    if (v == "today" || v == "yesterday") {
        const auto range = local_day_range(now, v == "today" ? 0 : -1);
        if (range) {
            out.modified.after_unix_seconds = range->first;
            out.modified.before_unix_seconds = range->second;
        }
    } else if (v == "week") {
        out.modified.after_unix_seconds = now - 7 * kDay;
        out.modified.before_unix_seconds = now + 1;
    } else if (v == "month") {
        out.modified.after_unix_seconds = now - 30 * kDay;
        out.modified.before_unix_seconds = now + 1;
    } else if (v == "year") {
        out.modified.after_unix_seconds = now - 365 * kDay;
        out.modified.before_unix_seconds = now + 1;
    } else if (v.starts_with("date:")) {
        if (const auto d = parse_iso_day_local(std::string_view(v).substr(5))) {
            const auto range = local_day_range(*d, 0);
            out.modified.after_unix_seconds = *d;
            out.modified.before_unix_seconds = range ? range->second : *d + kDay;
        }
    } else if (v.starts_with("after:")) {
        if (const auto d = parse_iso_day_local(std::string_view(v).substr(6))) out.modified.after_unix_seconds = *d;
    } else if (v.starts_with("before:")) {
        if (const auto d = parse_iso_day_local(std::string_view(v).substr(7))) out.modified.before_unix_seconds = *d;
    } else if (const auto d = parse_iso_day_local(v)) {
        const auto range = local_day_range(*d, 0);
        out.modified.after_unix_seconds = *d;
        out.modified.before_unix_seconds = range ? range->second : *d + kDay;
    } else if (const auto month = parse_iso_month_local(v)) {
        out.modified.after_unix_seconds = month->first;
        out.modified.before_unix_seconds = month->second;
    }
}

SearchFilter parse_impl(
    std::string_view query,
    PlatformDialect dialect,
    std::int64_t now_unix_seconds,
    const std::vector<std::string>& observed_extensions) {
    SearchFilter out;
    const std::string prefix(operator_prefix(dialect));
    const auto registered_extensions = extension_registry(observed_extensions);
    std::istringstream in{std::string(query)};
    std::string token;
    std::vector<std::string> text_parts;
    std::unordered_set<std::string> seen_ext;

    while (in >> token) {
        const bool prefixed = token.rfind(prefix, 0) == 0;
        if (!prefixed || token.size() == prefix.size()) {
            text_parts.push_back(token);
            continue;
        }

        const std::string body = token.substr(prefix.size());
        const std::string lower = lower_ascii(body);
        if (lower == "pin") {
            out.pinned_only = true;
            continue;
        }
        if (is_valid_control(body)) {
            apply_date_token(out, body, now_unix_seconds);
            continue;
        }
        if (looks_extension(body) && registered_extensions.contains(lower)) {
            if (seen_ext.insert(lower).second) out.extensions.push_back(lower);
            continue;
        }

        // Unknown/unregistered slash token is deliberately preserved as ordinary text.
        text_parts.push_back(token);
    }

    for (std::size_t i = 0; i < text_parts.size(); ++i) {
        if (i) out.text.push_back(' ');
        out.text += text_parts[i];
    }
    return out;
}

} // namespace

SearchFilter parse_search_query(std::string_view query, PlatformDialect dialect, std::int64_t now_unix_seconds) {
    return parse_impl(query, dialect, now_unix_seconds, {});
}

SearchFilter parse_search_query(
    std::string_view query,
    PlatformDialect dialect,
    std::int64_t now_unix_seconds,
    const std::vector<std::string>& observed_extensions) {
    return parse_impl(query, dialect, now_unix_seconds, observed_extensions);
}

std::vector<Suggestion> autocomplete(
    std::string_view query,
    PlatformDialect dialect,
    const std::vector<std::string>& observed_extensions) {
    const std::string prefix(operator_prefix(dialect));
    const auto last_space = query.find_last_of(" \t\n");
    const std::string_view tail = last_space == std::string_view::npos ? query : query.substr(last_space + 1);
    if (tail.rfind(prefix, 0) != 0) return {};
    if (dialect == PlatformDialect::UnixLike && tail.size() < 2) return {};

    const std::string needle = lower_ascii(tail.substr(prefix.size()));
    std::vector<Suggestion> out;
    const std::array<Suggestion, 11> fixed{{
        {prefix + "font", "Font settings"},
        {prefix + "index", "Add indexed folder"},
        {prefix + "drive", "Replace search folder"},
        {prefix + "reindex", "Rebuild local index"},
        {prefix + "roots", "Indexed folders"},
        {prefix + "pin", "Pinned"},
        {prefix + "today", "Modified today"},
        {prefix + "yesterday", "Modified yesterday"},
        {prefix + "week", "Last 7 days"},
        {prefix + "month", "Last 30 days"},
        {prefix + "year", "Last 365 days"},
    }};
    auto maybe_add = [&](const Suggestion& s) {
        const std::string body = lower_ascii(std::string_view(s.token).substr(prefix.size()));
        if (body.starts_with(needle)) out.push_back(s);
    };
    for (const auto& s : fixed) maybe_add(s);

    std::unordered_set<std::string> seen;
    for (const auto& ext0 : observed_extensions) {
        std::string ext = lower_ascii(ext0);
        if (!ext.empty() && ext.front() == '.') ext.erase(ext.begin());
        if (!looks_extension(ext) || !seen.insert(ext).second || !ext.starts_with(needle)) continue;
        out.push_back({prefix + ext, "." + ext + " files"});
    }
    std::sort(out.begin(), out.end(), [](const Suggestion& a, const Suggestion& b) {
        return a.token < b.token;
    });
    if (out.size() > 8) out.resize(8);
    return out;
}

} // namespace such::ui
