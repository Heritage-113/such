#include <such/ui/IndexCommands.h>

#include <algorithm>
#include <cctype>
#include <string>

namespace such::ui {
namespace {
std::string trim_lower(std::string_view value) {
    std::size_t first = 0;
    while (first < value.size() && std::isspace(static_cast<unsigned char>(value[first])) != 0) ++first;
    std::size_t last = value.size();
    while (last > first && std::isspace(static_cast<unsigned char>(value[last - 1])) != 0) --last;
    std::string out(value.substr(first, last - first));
    std::transform(out.begin(), out.end(), out.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return out;
}
}

IndexCommand parse_index_command(std::string_view query, PlatformDialect dialect) {
    const std::string value = trim_lower(query);
    const std::string prefix(operator_prefix(dialect));
    const std::string index_token = prefix + "index";
    if (value == index_token) return {IndexCommandKind::AddRoot, true, std::nullopt};
    if (value.starts_with(index_token + " ")) {
        std::string original(query);
        std::size_t first = 0;
        while (first < original.size() && std::isspace(static_cast<unsigned char>(original[first])) != 0) ++first;
        const std::size_t argument_start = first + index_token.size() + 1;
        std::string argument = argument_start < original.size() ? original.substr(argument_start) : std::string{};
        while (!argument.empty() && std::isspace(static_cast<unsigned char>(argument.back())) != 0) argument.pop_back();
        return {IndexCommandKind::AddRoot, true, argument.empty() ? std::nullopt : std::optional<std::string>(argument)};
    }
    const std::string drive_token = prefix + "drive";
    if (value == drive_token) return {IndexCommandKind::ReplaceRoot, true, std::nullopt};
    if (value.starts_with(drive_token + " ")) {
        std::string original(query);
        std::size_t first = 0;
        while (first < original.size() && std::isspace(static_cast<unsigned char>(original[first])) != 0) ++first;
        const std::size_t argument_start = first + drive_token.size() + 1;
        std::string argument = argument_start < original.size() ? original.substr(argument_start) : std::string{};
        while (!argument.empty() && std::isspace(static_cast<unsigned char>(argument.back())) != 0) argument.pop_back();
        return {IndexCommandKind::ReplaceRoot, true, argument.empty() ? std::nullopt : std::optional<std::string>(argument)};
    }
    if (value == prefix + "reindex") return {IndexCommandKind::Reindex, true, std::nullopt};
    if (value == prefix + "roots") return {IndexCommandKind::ShowRoots, true, std::nullopt};
    return {};
}

} // namespace such::ui
