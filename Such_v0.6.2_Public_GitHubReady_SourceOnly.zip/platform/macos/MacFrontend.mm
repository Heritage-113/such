#include <such/runtime/RuntimeClient.h>
#include <such/ui/FrontendLease.h>
#include <such/ui/IndexCommands.h>
#include <such/ui/FontSettings.h>
#include <such/ui/ResultView.h>
#include <such/ui/SearchDialect.h>

#import <AppKit/AppKit.h>
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>

#include <algorithm>
#include <cmath>
#include <ctime>
#include <filesystem>
#include <cstdint>
#include <vector>

namespace {
NSColor* paperColor() { return [NSColor colorWithCalibratedRed:243.0/255.0 green:239.0/255.0 blue:229.0/255.0 alpha:1.0]; }
NSColor* brightColor() { return [NSColor colorWithCalibratedRed:251.0/255.0 green:248.0/255.0 blue:239.0/255.0 alpha:1.0]; }
NSColor* darkGreen() { return [NSColor colorWithCalibratedRed:23.0/255.0 green:58.0/255.0 blue:43.0/255.0 alpha:1.0]; }
NSColor* pathGreen() { return [NSColor colorWithCalibratedRed:84.0/255.0 green:103.0/255.0 blue:91.0/255.0 alpha:1.0]; }
NSColor* hairline() { return [NSColor colorWithCalibratedRed:211.0/255.0 green:205.0/255.0 blue:191.0/255.0 alpha:1.0]; }

NSString* ns(const std::string& s) {
    NSString* value = [[NSString alloc] initWithBytes:s.data() length:s.size() encoding:NSUTF8StringEncoding];
    return value != nil ? value : @"";
}
NSMutableParagraphStyle* centeredParagraphStyle() {
    NSMutableParagraphStyle* style = [[NSMutableParagraphStyle alloc] init];
    style.alignment = NSTextAlignmentCenter;
    return style;
}
}

static NSString* gSuchFontFamily = nil;

static NSFont* suchFont(CGFloat size, NSFontWeight weight) {
    if (gSuchFontFamily.length > 0) {
        NSFont* custom = [NSFont fontWithName:gSuchFontFamily size:size];
        if (custom != nil) {
            if (weight >= NSFontWeightSemibold) {
                NSFont* bold = [[NSFontManager sharedFontManager] convertFont:custom toHaveTrait:NSBoldFontMask];
                if (bold != nil) return bold;
            }
            return custom;
        }
    }
    return [NSFont systemFontOfSize:size weight:weight];
}

@interface SuchResultRowView : NSView {
@private
    such::ui::ResultItem _item;
}
@property(nonatomic) CGFloat offsetX;
@property(nonatomic) CGFloat startX;
@property(nonatomic) BOOL dragging;
@property(nonatomic) BOOL allowLocalDemoMutation;
@property(nonatomic, copy) void (^indexAction)(BOOL indexed);
@property(nonatomic, copy) void (^pinAction)(BOOL pinned);
- (void)setItemValue:(const such::ui::ResultItem&)item;
@end

@implementation SuchResultRowView
- (void)setItemValue:(const such::ui::ResultItem&)item { _item = item; [self setNeedsDisplay:YES]; }
- (BOOL)isFlipped { return YES; }
- (instancetype)initWithFrame:(NSRect)frameRect {
    self = [super initWithFrame:frameRect];
    if (self) {
        self.wantsLayer = YES;
        _offsetX = 0.0;
    }
    return self;
}
- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    NSRect b = self.bounds;
    const CGFloat actionW = 72.0;
    if (self.offsetX < -1.0) {
        NSArray<NSString*>* labels = @[@"Location", (_item.indexed ? @"Unindex" : @"Index"), (_item.pinned ? @"Unpin" : @"Pin")];
        NSArray<NSColor*>* colors = @[darkGreen(), [NSColor colorWithCalibratedRed:34.0/255.0 green:76.0/255.0 blue:58.0/255.0 alpha:1], [NSColor colorWithCalibratedRed:47.0/255.0 green:91.0/255.0 blue:70.0/255.0 alpha:1]];
        CGFloat x = NSMaxX(b) - actionW * 3.0;
        for (NSInteger i = 0; i < 3; ++i) {
            NSRect r = NSMakeRect(x + actionW * i, 0, actionW, NSHeight(b));
            [colors[i] setFill]; NSRectFill(r);
            [labels[i] drawInRect:r withAttributes:@{NSFontAttributeName:suchFont(11.0, NSFontWeightRegular), NSForegroundColorAttributeName:NSColor.whiteColor, NSParagraphStyleAttributeName:centeredParagraphStyle()}];
        }
    }
#if defined(SUCH_EXPERIMENTAL_LEADING_SWIPE)
    else if (self.offsetX > 1.0) {
        NSArray<NSString*>* labels = @[@"Pin", @"Properties", @"Appearance"];
        NSArray<NSColor*>* colors = @[darkGreen(), [NSColor colorWithCalibratedRed:34.0/255.0 green:76.0/255.0 blue:58.0/255.0 alpha:1], [NSColor colorWithCalibratedRed:47.0/255.0 green:91.0/255.0 blue:70.0/255.0 alpha:1]];
        for (NSInteger i = 0; i < 3; ++i) {
            NSRect r = NSMakeRect(actionW * i, 0, actionW, NSHeight(b));
            [colors[i] setFill]; NSRectFill(r);
            [labels[i] drawInRect:r withAttributes:@{NSFontAttributeName:suchFont(11.0, NSFontWeightRegular), NSForegroundColorAttributeName:NSColor.whiteColor, NSParagraphStyleAttributeName:centeredParagraphStyle()}];
        }
    }
#endif

    NSRect row = NSOffsetRect(NSInsetRect(b, 0.5, 0.5), self.offsetX, 0.0);
    NSBezierPath* path = [NSBezierPath bezierPathWithRoundedRect:row xRadius:5.0 yRadius:5.0];
    [brightColor() setFill]; [path fill];
    [hairline() setStroke]; path.lineWidth = 1.0; [path stroke];

    NSString* fullPath = ns(_item.path);
    NSImage* icon = [[NSWorkspace sharedWorkspace] iconForFile:fullPath];
    if (icon == nil || icon.size.width <= 0) {
        UTType* type = [UTType typeWithFilenameExtension:ns(_item.extension)];
        if (type) icon = [[NSWorkspace sharedWorkspace] iconForContentType:type];
    }
    const CGFloat iconSize = 36.0;
    NSRect iconRect = NSMakeRect(NSMinX(row) + 12.0, NSMidY(row) - iconSize/2.0, iconSize, iconSize);
    [icon drawInRect:iconRect];

    NSString* ext = [ns(_item.extension) uppercaseString];
    NSDictionary* badgeAttrs = @{NSFontAttributeName:suchFont(9.0, NSFontWeightBold), NSForegroundColorAttributeName:NSColor.whiteColor};
    NSSize extSize = [ext sizeWithAttributes:badgeAttrs];
    NSRect badge = NSMakeRect(NSMaxX(iconRect) - extSize.width, NSMaxY(iconRect) - 13.0, extSize.width + 8.0, 14.0);
    NSBezierPath* bp = [NSBezierPath bezierPathWithRoundedRect:badge xRadius:3.0 yRadius:3.0]; [darkGreen() setFill]; [bp fill];
    [ext drawAtPoint:NSMakePoint(NSMinX(badge)+4.0, NSMinY(badge)+2.0) withAttributes:badgeAttrs];

    CGFloat tx = NSMaxX(iconRect) + 13.0;
    CGFloat right = NSMaxX(row) - 14.0;
    NSMutableParagraphStyle* filenameStyle = [[NSMutableParagraphStyle alloc] init];
    filenameStyle.lineBreakMode = NSLineBreakByTruncatingTail;
    NSMutableParagraphStyle* pathStyle = [[NSMutableParagraphStyle alloc] init];
    pathStyle.lineBreakMode = NSLineBreakByTruncatingMiddle;
    NSRect fn = NSMakeRect(tx, NSMinY(row)+9.0, right-tx-(_item.pinned?24.0:0.0), 21.0);
    [ns(_item.filename) drawInRect:fn withAttributes:@{
        NSFontAttributeName:suchFont(15.0, NSFontWeightSemibold),
        NSForegroundColorAttributeName:darkGreen(),
        NSParagraphStyleAttributeName:filenameStyle}];
    NSRect pr = NSMakeRect(tx, NSMinY(row)+31.0, right-tx, 18.0);
    [fullPath drawInRect:pr withAttributes:@{
        NSFontAttributeName:suchFont(11.5, NSFontWeightRegular),
        NSForegroundColorAttributeName:pathGreen(),
        NSParagraphStyleAttributeName:pathStyle}];
    if (_item.pinned) [@"📌" drawAtPoint:NSMakePoint(NSMaxX(row)-29.0, NSMinY(row)+10.0) withAttributes:@{NSFontAttributeName:suchFont(12.0, NSFontWeightRegular)}];
}
- (void)mouseDown:(NSEvent*)event {
    const NSPoint point = [self convertPoint:event.locationInWindow fromView:nil];
    const CGFloat actionW = 72.0;
    if (self.offsetX <= -actionW * 2.5 && point.x >= NSWidth(self.bounds) - actionW * 3.0) {
        const NSInteger actionIndex = std::clamp(
            (NSInteger)((point.x - (NSWidth(self.bounds) - actionW * 3.0)) / actionW),
            (NSInteger)0, (NSInteger)2);
        if (actionIndex == 0) {
            NSURL* url = [NSURL fileURLWithPath:ns(_item.path)];
            if (url) [[NSWorkspace sharedWorkspace] activateFileViewerSelectingURLs:@[url]];
        } else if (actionIndex == 1) {
            // Index persistence belongs to SearchRuntimeClient. Only explicit demo
            // rows may mutate their local visual fixture.
            if (self.allowLocalDemoMutation) _item.indexed = !_item.indexed;
            else if (self.indexAction) self.indexAction(!_item.indexed);
        } else {
            if (self.allowLocalDemoMutation) _item.pinned = !_item.pinned;
            else if (self.pinAction) self.pinAction(!_item.pinned);
        }
        self.offsetX = 0.0;
        self.dragging = NO;
        [self setNeedsDisplay:YES];
        return;
    }
    self.startX = point.x;
    self.dragging = YES;
}
- (void)mouseDragged:(NSEvent*)event {
    if (!self.dragging) return;
    CGFloat x = [self convertPoint:event.locationInWindow fromView:nil].x;
    CGFloat dx = x - self.startX;
#if defined(SUCH_EXPERIMENTAL_LEADING_SWIPE)
    self.offsetX = std::clamp(dx, -216.0, 216.0);
#else
    // Authoritative Design.md: closed rows open only to the left. A right drag
    // closes a previously opened trailing row; it never opens a second tray.
    const CGFloat base = self.offsetX <= -1.0 ? -216.0 : 0.0;
    self.offsetX = std::clamp(base + dx, -216.0, 0.0);
#endif
    [self setNeedsDisplay:YES];
}
- (void)mouseUp:(NSEvent*)event {
    (void)event;
    if (!self.dragging) return;
    self.dragging = NO;
#if defined(SUCH_EXPERIMENTAL_LEADING_SWIPE)
    if (self.offsetX > self.bounds.size.width * 0.60) {
        // Appearance/Pin persistence is runtime-owned in production. The retained
        // leading-side experiment may mutate only explicit demo fixture state.
        if (self.allowLocalDemoMutation) _item.pinned = !_item.pinned;
        self.offsetX = 0.0;
    } else if (fabs(self.offsetX) >= 72.0) {
        self.offsetX = self.offsetX > 0 ? 216.0 : -216.0;
    } else {
        self.offsetX = 0.0;
    }
#else
    self.offsetX = self.offsetX <= -72.0 ? -216.0 : 0.0;
#endif
    [self setNeedsDisplay:YES];
}
@end

@interface SuchAppDelegate : NSObject <NSApplicationDelegate, NSSearchFieldDelegate> {
@private
    such::runtime::RuntimeClient _runtime;
    std::uint64_t _runtimeGeneration;
}
@property(nonatomic, strong) NSWindow* window;
@property(nonatomic, strong) NSSearchField* search;
@property(nonatomic, strong) NSScrollView* resultsScroll;
@property(nonatomic, strong) NSStackView* results;
@property(nonatomic, strong) NSTimer* runtimeTimer;
@property(nonatomic) BOOL demo;
@end

@implementation SuchAppDelegate
- (instancetype)init {
    self = [super init];
    if (self) {
        NSArray<NSString*>* args = NSProcessInfo.processInfo.arguments;
        _demo = [args containsObject:@"--demo"];
    }
    return self;
}
- (void)applicationDidFinishLaunching:(NSNotification*)notification {
    (void)notification;
    std::string runtimeError;
    (void)_runtime.load(&runtimeError);
    _runtimeGeneration = _runtime.generation();
    if (!self.demo) {
        const auto status = _runtime.status();
        if (status.indexed_files == 0 && !status.roots.empty()) _runtime.reindex_async();
    }
    if (const auto preferred = such::ui::load_font_preference(); preferred && !preferred->empty()) {
        NSString* name = [NSString stringWithUTF8String:preferred->c_str()];
        if (name != nil && [NSFont fontWithName:name size:15.0] != nil) gSuchFontFamily = name;
    }
    self.window = [[NSWindow alloc] initWithContentRect:NSMakeRect(0,0,760,600)
                                              styleMask:(NSWindowStyleMaskTitled|NSWindowStyleMaskClosable|NSWindowStyleMaskMiniaturizable|NSWindowStyleMaskResizable)
                                                backing:NSBackingStoreBuffered defer:NO];
    self.window.title = @"Such v0.6.2";
    self.window.minSize = NSMakeSize(420,390);
    [self.window center];
    NSView* root = self.window.contentView;
    root.wantsLayer = YES;
    root.layer.backgroundColor = paperColor().CGColor;

    self.search = [[NSSearchField alloc] initWithFrame:NSZeroRect];
    self.search.translatesAutoresizingMaskIntoConstraints = NO;
    self.search.placeholderString = @"2026 Heritage Inc.";
    self.search.delegate = self;
    if ([self.search.cell respondsToSelector:@selector(setPlaceholderAttributedString:)]) {
        self.search.cell.placeholderAttributedString = [[NSAttributedString alloc] initWithString:@"2026 Heritage Inc." attributes:@{NSForegroundColorAttributeName:[NSColor colorWithCalibratedWhite:0.70 alpha:1.0]}];
    }
    self.search.font = suchFont(15.0, NSFontWeightRegular);
    self.search.focusRingType = NSFocusRingTypeNone;
    self.search.wantsLayer = YES;
    self.search.layer.cornerRadius = 7.0;
    self.search.layer.borderWidth = 1.0;
    self.search.layer.borderColor = darkGreen().CGColor;
    self.search.layer.backgroundColor = brightColor().CGColor;
    [root addSubview:self.search];

    self.resultsScroll = [[NSScrollView alloc] initWithFrame:NSZeroRect];
    self.resultsScroll.translatesAutoresizingMaskIntoConstraints = NO;
    self.resultsScroll.drawsBackground = NO;
    self.resultsScroll.borderType = NSNoBorder;
    self.resultsScroll.hasVerticalScroller = YES;
    self.resultsScroll.autohidesScrollers = YES;
    [root addSubview:self.resultsScroll];

    self.results = [[NSStackView alloc] initWithFrame:NSZeroRect];
    self.results.orientation = NSUserInterfaceLayoutOrientationVertical;
    self.results.alignment = NSLayoutAttributeLeading;
    self.results.spacing = 7.0;
    self.results.translatesAutoresizingMaskIntoConstraints = NO;
    self.resultsScroll.documentView = self.results;

    [NSLayoutConstraint activateConstraints:@[
        [self.search.topAnchor constraintEqualToAnchor:root.topAnchor constant:18.0],
        [self.search.leadingAnchor constraintEqualToAnchor:root.leadingAnchor constant:20.0],
        [self.search.trailingAnchor constraintEqualToAnchor:root.trailingAnchor constant:-20.0],
        [self.search.heightAnchor constraintEqualToConstant:50.0],
        [self.resultsScroll.topAnchor constraintEqualToAnchor:self.search.bottomAnchor constant:13.0],
        [self.resultsScroll.leadingAnchor constraintEqualToAnchor:root.leadingAnchor constant:20.0],
        [self.resultsScroll.trailingAnchor constraintEqualToAnchor:root.trailingAnchor constant:-20.0],
        [self.resultsScroll.bottomAnchor constraintEqualToAnchor:root.bottomAnchor constant:-12.0],
        [self.results.topAnchor constraintEqualToAnchor:self.resultsScroll.contentView.topAnchor],
        [self.results.leadingAnchor constraintEqualToAnchor:self.resultsScroll.contentView.leadingAnchor],
        [self.results.trailingAnchor constraintEqualToAnchor:self.resultsScroll.contentView.trailingAnchor],
        [self.results.widthAnchor constraintEqualToAnchor:self.resultsScroll.contentView.widthAnchor],
    ]];

    [self rebuildResults];
    self.runtimeTimer = [NSTimer scheduledTimerWithTimeInterval:0.25 target:self selector:@selector(pollRuntime:) userInfo:nil repeats:YES];
    [self.window makeKeyAndOrderFront:nil];
    [self.window makeFirstResponder:self.search];
    [NSApp activateIgnoringOtherApps:YES];
}
- (BOOL)applyFontFamilyUtf8:(const std::string&)family {
    if (family.empty()) {
        gSuchFontFamily = nil;
        std::string error;
        (void)such::ui::clear_font_preference(&error);
    } else {
        NSString* name = [NSString stringWithUTF8String:family.c_str()];
        if (name == nil || [NSFont fontWithName:name size:15.0] == nil) return NO;
        gSuchFontFamily = name;
        std::string error;
        (void)such::ui::save_font_preference(family, &error);
    }
    self.search.font = suchFont(15.0, NSFontWeightRegular);
    [self rebuildResults];
    return YES;
}
- (void)showFontPicker {
    NSAlert* alert = [[NSAlert alloc] init];
    alert.messageText = @"Font";
    alert.informativeText = @"Choose a Such UI font. Unavailable fonts are ignored.";
    const auto& options = such::ui::builtin_font_options();
    for (const auto& option : options) [alert addButtonWithTitle:[NSString stringWithUTF8String:option.label.c_str()]];
    [alert addButtonWithTitle:@"System Default"];
    const NSModalResponse response = [alert runModal];
    const NSInteger index = response - NSAlertFirstButtonReturn;
    if (index >= 0 && index < (NSInteger)options.size()) {
        (void)[self applyFontFamilyUtf8:options[(std::size_t)index].family];
    } else if (index == (NSInteger)options.size()) {
        (void)[self applyFontFamilyUtf8:std::string{}];
    }
}
- (void)pollRuntime:(NSTimer*)timer {
    (void)timer;
    const auto generation = _runtime.generation();
    if (generation != _runtimeGeneration) {
        _runtimeGeneration = generation;
        [self rebuildResults];
    }
}
- (BOOL)executeIndexCommand:(const std::string&)query {
    const auto command = such::ui::parse_index_command(query, such::ui::PlatformDialect::UnixLike);
    if (!command.matched) return NO;
    std::string error;
    switch (command.kind) {
        case such::ui::IndexCommandKind::AddRoot: {
            std::string path;
            if (command.argument.has_value()) path = *command.argument;
            else {
                NSOpenPanel* panel = [NSOpenPanel openPanel];
                panel.canChooseDirectories = YES;
                panel.canChooseFiles = NO;
                panel.allowsMultipleSelection = NO;
                if ([panel runModal] != NSModalResponseOK || panel.URL == nil) return YES;
                const char* utf8 = panel.URL.path.UTF8String;
                if (utf8 != nullptr) path = utf8;
            }
            if (!path.empty()) (void)_runtime.add_root(path, &error);
            self.search.stringValue = @"";
            break;
        }
        case such::ui::IndexCommandKind::ReplaceRoot: {
            std::string path;
            if (command.argument.has_value()) path = *command.argument;
            else {
                NSOpenPanel* panel = [NSOpenPanel openPanel];
                panel.canChooseDirectories = YES;
                panel.canChooseFiles = NO;
                panel.allowsMultipleSelection = NO;
                if ([panel runModal] != NSModalResponseOK || panel.URL == nil) return YES;
                const char* utf8 = panel.URL.path.UTF8String;
                if (utf8 != nullptr) path = utf8;
            }
            if (!path.empty()) (void)_runtime.replace_roots({std::filesystem::path(path)}, &error);
            self.search.stringValue = @"";
            break;
        }
        case such::ui::IndexCommandKind::Reindex:
            _runtime.reindex_async();
            self.search.stringValue = @"";
            break;
        case such::ui::IndexCommandKind::ShowRoots:
            [self rebuildResults];
            break;
        case such::ui::IndexCommandKind::NoCommand:
            return NO;
    }
    [self rebuildResults];
    return YES;
}
- (BOOL)control:(NSControl*)control textView:(NSTextView*)textView doCommandBySelector:(SEL)selector {
    (void)control; (void)textView;
    if (selector != @selector(insertNewline:)) return NO;
    const char* utf8 = self.search.stringValue.UTF8String;
    const std::string query = utf8 != nullptr ? utf8 : "";
    const auto cmd = such::ui::parse_font_command(query, such::ui::PlatformDialect::UnixLike);
    if (cmd.matched) {
        if (cmd.show_picker) [self showFontPicker];
        else if (cmd.requested_family.has_value()) (void)[self applyFontFamilyUtf8:*cmd.requested_family];
        self.search.stringValue = @"";
        [self rebuildResults];
        return YES;
    }
    return [self executeIndexCommand:query];
}
- (void)controlTextDidChange:(NSNotification*)obj { (void)obj; [self rebuildResults]; }
- (void)rebuildResults {
    for (NSView* v in self.results.arrangedSubviews.copy) { [self.results removeArrangedSubview:v]; [v removeFromSuperview]; }
    const char* utf8 = self.search.stringValue.UTF8String;
    const std::string q = utf8 != nullptr ? utf8 : "";
    if (such::ui::parse_font_command(q, such::ui::PlatformDialect::UnixLike).matched) return;

    std::vector<such::ui::ResultItem> rows;
    const auto indexCommand = such::ui::parse_index_command(q, such::ui::PlatformDialect::UnixLike);
    if (indexCommand.matched && indexCommand.kind == such::ui::IndexCommandKind::ShowRoots) {
        for (const auto& root : _runtime.roots()) {
            such::ui::ResultItem item;
            item.path = root;
            item.filename = std::filesystem::path(root).filename().string();
            if (item.filename.empty()) item.filename = root;
            rows.push_back(std::move(item));
        }
    } else if (indexCommand.matched) {
        return;
    } else if (self.demo) {
        rows = such::ui::make_demo_results(q, such::ui::PlatformDialect::UnixLike, static_cast<std::int64_t>(std::time(nullptr)));
    } else {
        rows = _runtime.search(q, such::ui::PlatformDialect::UnixLike);
    }

    __weak SuchAppDelegate* weakSelf = self;
    for (const auto& item : rows) {
        SuchResultRowView* row = [[SuchResultRowView alloc] initWithFrame:NSMakeRect(0,0,100,62)];
        [row setItemValue:item];
        row.allowLocalDemoMutation = self.demo;
        NSString* itemPath = ns(item.path);
        row.indexAction = ^(BOOL indexed) {
            SuchAppDelegate* strongSelf = weakSelf;
            if (!strongSelf) return;
            const char* pathUtf8 = itemPath.UTF8String;
            if (pathUtf8 != nullptr) { std::string error; (void)strongSelf->_runtime.set_indexed(pathUtf8, indexed, &error); }
            [strongSelf rebuildResults];
        };
        row.pinAction = ^(BOOL pinned) {
            SuchAppDelegate* strongSelf = weakSelf;
            if (!strongSelf) return;
            const char* pathUtf8 = itemPath.UTF8String;
            if (pathUtf8 != nullptr) { std::string error; (void)strongSelf->_runtime.set_pinned(pathUtf8, pinned, &error); }
            [strongSelf rebuildResults];
        };
        [row.heightAnchor constraintEqualToConstant:62.0].active = YES;
        [row.widthAnchor constraintEqualToAnchor:self.results.widthAnchor].active = YES;
        [self.results addArrangedSubview:row];
    }
}
- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication*)sender { (void)sender; return YES; }
@end

int main(int argc, const char* argv[]) {
    (void)argc; (void)argv;
    auto lease = such::ui::FrontendLease::try_acquire(such::ui::FrontendMode::Gui);
    if (!lease.acquired()) {
        @autoreleasepool {
            NSAlert* alert = [[NSAlert alloc] init];
            alert.messageText = @"Such is already active";
            alert.informativeText = @"Close the Such CLI or other Such frontend before opening the GUI.";
            [alert runModal];
        }
        return 23;
    }
    @autoreleasepool {
        NSApplication* app = [NSApplication sharedApplication];
        SuchAppDelegate* delegate = [[SuchAppDelegate alloc] init];
        app.delegate = delegate;
        [app run];
    }
    return 0;
}
