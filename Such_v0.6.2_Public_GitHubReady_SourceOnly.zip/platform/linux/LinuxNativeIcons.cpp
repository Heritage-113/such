#include "LinuxNativeIcons.h"

#include <png.h>

#include <algorithm>
#include <array>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <memory>
#include <string_view>

namespace such::platform::linuxui {
namespace {

std::string lower_ascii(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    if (!s.empty() && s.front() == '.') s.erase(s.begin());
    return s;
}

std::string icon_name_for_extension(std::string ext) {
    ext = lower_ascii(std::move(ext));
    if (ext == "xls" || ext == "xlsx" || ext == "ods" || ext == "csv") return "x-office-spreadsheet";
    if (ext == "doc" || ext == "docx" || ext == "odt" || ext == "rtf") return "x-office-document";
    if (ext == "ppt" || ext == "pptx" || ext == "odp") return "x-office-presentation";
    if (ext == "dwg" || ext == "dxf" || ext == "svg" || ext == "ai") return "x-office-drawing";
    if (ext == "png" || ext == "jpg" || ext == "jpeg" || ext == "gif" || ext == "webp" || ext == "tif" || ext == "tiff") return "image-x-generic";
    if (ext == "mp3" || ext == "wav" || ext == "flac" || ext == "m4a") return "audio-x-generic";
    if (ext == "mp4" || ext == "mov" || ext == "mkv" || ext == "avi") return "video-x-generic";
    if (ext == "exe" || ext == "appimage" || ext == "bin") return "application-x-executable";
    return "text-x-generic";
}

std::vector<std::filesystem::path> theme_roots() {
    std::vector<std::filesystem::path> roots;
    if (const char* home = std::getenv("HOME")) {
        roots.emplace_back(std::filesystem::path(home) / ".local/share/icons");
        roots.emplace_back(std::filesystem::path(home) / ".icons");
    }
    if (const char* data = std::getenv("XDG_DATA_DIRS")) {
        std::string s(data);
        std::size_t pos = 0;
        while (pos <= s.size()) {
            const auto next = s.find(':', pos);
            const std::string part = s.substr(pos, next == std::string::npos ? std::string::npos : next - pos);
            if (!part.empty()) roots.emplace_back(std::filesystem::path(part) / "icons");
            if (next == std::string::npos) break;
            pos = next + 1;
        }
    }
    roots.emplace_back("/usr/share/icons");
    return roots;
}

std::filesystem::path find_theme_png(const std::string& icon_name) {
    static constexpr std::array<std::string_view, 4> themes{"Adwaita", "hicolor", "HighContrast", "gnome"};
    static constexpr std::array<std::string_view, 6> sizes{"48x48", "64x64", "32x32", "24x24", "22x22", "16x16"};
    const auto roots = theme_roots();
    for (const auto& root : roots) {
        for (const auto theme : themes) {
            for (const auto size : sizes) {
                const auto p = root / theme / size / "mimetypes" / (icon_name + ".png");
                std::error_code ec;
                if (std::filesystem::is_regular_file(p, ec)) return p;
            }
        }
    }
    return {};
}

RgbaIcon load_png(const std::filesystem::path& path) {
    RgbaIcon out;
    FILE* fp = std::fopen(path.string().c_str(), "rb");
    if (!fp) return out;
    struct FileCloser { void operator()(FILE* f) const { if (f) std::fclose(f); } };
    std::unique_ptr<FILE, FileCloser> file(fp);

    png_structp png = png_create_read_struct(PNG_LIBPNG_VER_STRING, nullptr, nullptr, nullptr);
    if (!png) return out;
    png_infop info = png_create_info_struct(png);
    if (!info) { png_destroy_read_struct(&png, nullptr, nullptr); return out; }
    if (setjmp(png_jmpbuf(png))) { png_destroy_read_struct(&png, &info, nullptr); return {}; }

    png_init_io(png, fp);
    png_read_info(png, info);
    png_uint_32 width = 0, height = 0;
    int bit_depth = 0, color_type = 0;
    png_get_IHDR(png, info, &width, &height, &bit_depth, &color_type, nullptr, nullptr, nullptr);
    if (bit_depth == 16) png_set_strip_16(png);
    if (color_type == PNG_COLOR_TYPE_PALETTE) png_set_palette_to_rgb(png);
    if (color_type == PNG_COLOR_TYPE_GRAY && bit_depth < 8) png_set_expand_gray_1_2_4_to_8(png);
    if (png_get_valid(png, info, PNG_INFO_tRNS)) png_set_tRNS_to_alpha(png);
    if (color_type == PNG_COLOR_TYPE_GRAY || color_type == PNG_COLOR_TYPE_GRAY_ALPHA) png_set_gray_to_rgb(png);
    if ((color_type & PNG_COLOR_MASK_ALPHA) == 0 && !png_get_valid(png, info, PNG_INFO_tRNS)) png_set_add_alpha(png, 0xFF, PNG_FILLER_AFTER);
    png_read_update_info(png, info);

    // Desktop theme assets are trusted-ish but still external input. Bound decoded
    // dimensions before multiplication/allocation so a malformed PNG cannot overflow
    // the size calculation or force an absurd UI-thread allocation.
    constexpr png_uint_32 kMaxIconDimension = 4096;
    if (width == 0 || height == 0 || width > kMaxIconDimension || height > kMaxIconDimension) {
        png_destroy_read_struct(&png, &info, nullptr);
        return {};
    }
    const std::size_t pixel_count = static_cast<std::size_t>(width) * static_cast<std::size_t>(height);
    if (pixel_count > (static_cast<std::size_t>(-1) / 4u)) {
        png_destroy_read_struct(&png, &info, nullptr);
        return {};
    }
    out.width = static_cast<int>(width);
    out.height = static_cast<int>(height);
    out.rgba.resize(pixel_count * 4u);
    std::vector<png_bytep> rows(static_cast<std::size_t>(out.height));
    for (int y = 0; y < out.height; ++y) rows[static_cast<std::size_t>(y)] = out.rgba.data() + static_cast<std::size_t>(y * out.width * 4);
    png_read_image(png, rows.data());
    png_read_end(png, nullptr);
    png_destroy_read_struct(&png, &info, nullptr);
    return out;
}

RgbaIcon load_system_icon_for_extension(const std::string& ext) {
    const std::string requested = icon_name_for_extension(ext);
    auto p = find_theme_png(requested);
    if (p.empty() && requested != "text-x-generic") p = find_theme_png("text-x-generic");
    if (p.empty()) p = find_theme_png("application-x-generic");
    return p.empty() ? RgbaIcon{} : load_png(p);
}

unsigned long pixel_from_rgb(unsigned long rgb) {
    return rgb & 0x00FFFFFFul;
}

} // namespace

const RgbaIcon& NativeIconCache::icon_for_extension(const std::string& extension) {
    const std::string key = lower_ascii(extension);
    const auto it = cache_.find(key);
    if (it != cache_.end()) return it->second;
    return cache_.emplace(key, load_system_icon_for_extension(key)).first->second;
}

void NativeIconCache::draw(Display* display, Window window, GC gc, const RgbaIcon& icon,
                           int x, int y, int target_size, unsigned long background_rgb) const {
    if (!icon.valid() || target_size <= 0) return;
    const int screen = DefaultScreen(display);
    const int depth = DefaultDepth(display, screen);
    Visual* visual = DefaultVisual(display, screen);
    const int bytes_per_pixel = 4;
    const std::size_t bytes = static_cast<std::size_t>(target_size * target_size * bytes_per_pixel);
    char* data = static_cast<char*>(std::calloc(bytes, 1));
    if (!data) return;

    const int br = static_cast<int>((background_rgb >> 16) & 0xFFu);
    const int bg = static_cast<int>((background_rgb >> 8) & 0xFFu);
    const int bb = static_cast<int>(background_rgb & 0xFFu);

    XImage* image = XCreateImage(display, visual, static_cast<unsigned>(depth), ZPixmap, 0, data,
                                 static_cast<unsigned>(target_size), static_cast<unsigned>(target_size), 32, 0);
    if (!image) { std::free(data); return; }

    for (int dy = 0; dy < target_size; ++dy) {
        const int sy = std::clamp((dy * icon.height) / target_size, 0, icon.height - 1);
        for (int dx = 0; dx < target_size; ++dx) {
            const int sx = std::clamp((dx * icon.width) / target_size, 0, icon.width - 1);
            const std::size_t si = static_cast<std::size_t>((sy * icon.width + sx) * 4);
            const int a = icon.rgba[si + 3];
            const int r = (icon.rgba[si] * a + br * (255 - a)) / 255;
            const int g = (icon.rgba[si + 1] * a + bg * (255 - a)) / 255;
            const int b = (icon.rgba[si + 2] * a + bb * (255 - a)) / 255;
            const unsigned long pixel = pixel_from_rgb((static_cast<unsigned long>(r) << 16) |
                                                        (static_cast<unsigned long>(g) << 8) |
                                                        static_cast<unsigned long>(b));
            XPutPixel(image, dx, dy, pixel);
        }
    }
    XPutImage(display, window, gc, image, 0, 0, x, y, static_cast<unsigned>(target_size), static_cast<unsigned>(target_size));
    XDestroyImage(image); // also frees data
}

} // namespace such::platform::linuxui
