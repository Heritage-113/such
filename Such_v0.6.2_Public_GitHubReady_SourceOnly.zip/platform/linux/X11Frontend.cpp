#include <such/runtime/RuntimeClient.h>
#include <such/ui/DesignContract.h>
#include <such/ui/IndexCommands.h>
#include <such/ui/FrontendLease.h>
#include <such/ui/FontSettings.h>
#include <such/ui/ResponsiveLayout.h>
#include <such/ui/ResultView.h>
#include <such/ui/SearchDialect.h>
#include <such/ui/SwipeActions.h>

#include "LinuxNativeIcons.h"

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <clocale>
#include <csignal>
#include <filesystem>
#include <string>
#include <vector>
#include <unistd.h>

namespace {
#if defined(SUCH_EXPERIMENTAL_LEADING_SWIPE)
constexpr bool kAllowLeadingSwipe = true;
#else
constexpr bool kAllowLeadingSwipe = false;
#endif
constexpr unsigned long kPaper = 0xF3EFE5;
constexpr unsigned long kBright = 0xFBF8EF;
constexpr unsigned long kDarkGreen = 0x173A2B;
constexpr unsigned long kPathGreen = 0x54675B;
constexpr unsigned long kPlaceholderGray = 0xB8B5AD;
constexpr unsigned long kHairline = 0xD3CDBF;
constexpr unsigned long kHighlight = 0xFFFDF7;
constexpr unsigned long kAction2 = 0x224C3A;
constexpr unsigned long kAction3 = 0x2F5B46;

XFontSet gFontSet = nullptr;
XIM gInputMethod = nullptr;
XIC gInputContext = nullptr;

struct UiState {
    std::string query;
    std::vector<such::ui::ResultItem> results;
    std::vector<such::ui::Suggestion> suggestions;
    such::ui::SwipeController swipe{216.0f, kAllowLeadingSwipe};
    int selected = -1;
    bool demo = false;
    bool smoke = false;
    int width = 760;
    int height = 600;
    std::chrono::steady_clock::time_point last_motion = std::chrono::steady_clock::now();
    such::platform::linuxui::NativeIconCache icon_cache;
    std::string font_family;
    such::runtime::RuntimeClient runtime;
    std::uint64_t runtime_generation = 0;
    float scroll_dip = 0.0f;
};

void set_color(Display* d, GC gc, unsigned long color) {
    (void)d;
    XSetForeground(d, gc, color);
}

void draw_utf8(Display* d, Window w, GC gc, int x, int y, const std::string& text) {
    if (text.empty()) return;
    if (gFontSet) {
        Xutf8DrawString(d, w, gFontSet, gc, x, y, text.c_str(), static_cast<int>(text.size()));
    } else {
        XDrawString(d, w, gc, x, y, text.c_str(), static_cast<int>(text.size()));
    }
}

int utf8_text_width(const std::string& text) {
    if (text.empty()) return 0;
    if (gFontSet) {
        XRectangle ink{};
        XRectangle logical{};
        Xutf8TextExtents(gFontSet, text.c_str(), static_cast<int>(text.size()), &ink, &logical);
        return logical.width;
    }
    return static_cast<int>(text.size()) * 7;
}

void pop_utf8_codepoint(std::string& text) {
    if (text.empty()) return;
    text.pop_back();
    while (!text.empty() && (static_cast<unsigned char>(text.back()) & 0xC0u) == 0x80u) text.pop_back();
}

std::string ellipsize_utf8(std::string text, int max_width) {
    if (max_width <= 0) return {};
    if (utf8_text_width(text) <= max_width) return text;
    constexpr const char* suffix = "...";
    const int suffix_width = utf8_text_width(suffix);
    while (!text.empty() && utf8_text_width(text) + suffix_width > max_width) pop_utf8_codepoint(text);
    return text + suffix;
}

void fill_round_rect(Display* d, Window w, GC gc, int x, int y, int width, int height, int radius, unsigned long color) {
    if (width <= 0 || height <= 0) return;
    radius = std::clamp(radius, 0, std::min(width, height) / 2);
    set_color(d, gc, color);
    if (radius == 0) {
        XFillRectangle(d, w, gc, x, y, static_cast<unsigned>(width), static_cast<unsigned>(height));
        return;
    }
    XFillRectangle(d, w, gc, x + radius, y, static_cast<unsigned>(std::max(1, width - radius * 2)), static_cast<unsigned>(height));
    XFillRectangle(d, w, gc, x, y + radius, static_cast<unsigned>(width), static_cast<unsigned>(std::max(1, height - radius * 2)));
    const int dia = radius * 2;
    XFillArc(d, w, gc, x, y, static_cast<unsigned>(dia), static_cast<unsigned>(dia), 90 * 64, 90 * 64);
    XFillArc(d, w, gc, x + width - dia, y, static_cast<unsigned>(dia), static_cast<unsigned>(dia), 0, 90 * 64);
    XFillArc(d, w, gc, x, y + height - dia, static_cast<unsigned>(dia), static_cast<unsigned>(dia), 180 * 64, 90 * 64);
    XFillArc(d, w, gc, x + width - dia, y + height - dia, static_cast<unsigned>(dia), static_cast<unsigned>(dia), 270 * 64, 90 * 64);
}

void stroke_round_rect(Display* d, Window w, GC gc, int x, int y, int width, int height, int radius, unsigned long color) {
    set_color(d, gc, color);
    XDrawRectangle(d, w, gc, x, y, static_cast<unsigned>(std::max(1, width - 1)), static_cast<unsigned>(std::max(1, height - 1)));
    (void)radius; // Core X11 has no antialiased rounded stroke; fill shape carries the small radius.
}

void draw_search_glyph(Display* d, Window w, GC gc, int cx, int cy) {
    set_color(d, gc, kDarkGreen);
    XDrawArc(d, w, gc, cx - 6, cy - 6, 12, 12, 0, 360 * 64);
    XDrawLine(d, w, gc, cx + 4, cy + 4, cx + 9, cy + 9);
}

void draw_pin(Display* d, Window w, GC gc, int x, int y) {
    set_color(d, gc, kDarkGreen);
    XFillArc(d, w, gc, x, y, 8, 5, 0, 360 * 64);
    XDrawLine(d, w, gc, x + 4, y + 3, x + 4, y + 11);
    XDrawLine(d, w, gc, x + 4, y + 11, x + 2, y + 14);
}

void draw_badge(Display* d, Window w, GC gc, const std::string& ext, int xRight, int yBottom) {
    if (ext.empty()) return;
    std::string up = ext;
    std::transform(up.begin(), up.end(), up.begin(), [](unsigned char c) { return static_cast<char>(std::toupper(c)); });
    if (up.size() > 5) up.resize(5);
    const int bw = static_cast<int>(up.size()) * 7 + 10;
    const int bh = 16;
    fill_round_rect(d, w, gc, xRight - bw, yBottom - bh, bw, bh, 3, kDarkGreen);
    set_color(d, gc, 0xFFFFFF);
    draw_utf8(d, w, gc, xRight - bw + 5, yBottom - 4, up);
}

void draw_action_tray(Display* d, Window w, GC gc, const such::ui::RectF& row, such::ui::SwipeSide side,
                      const such::ui::ResponsiveMetrics& m, const such::ui::ResultItem& item) {
    if (side == such::ui::SwipeSide::Inactive) return;
    const int aw = static_cast<int>(std::lround(m.swipe_action_width));
    const int total = aw * 3;
    const int rowX = static_cast<int>(std::lround(row.x));
    const int rowY = static_cast<int>(std::lround(row.y));
    const int rowW = static_cast<int>(std::lround(row.width));
    const int rowH = static_cast<int>(std::lround(row.height));
    const int x0 = side == such::ui::SwipeSide::Trailing ? rowX + rowW - total : rowX;
    const auto actions = such::ui::actions_for_side(side);
    const std::array<unsigned long, 3> colors{kDarkGreen, kAction2, kAction3};
    for (int i = 0; i < 3; ++i) {
        set_color(d, gc, colors[static_cast<std::size_t>(i)]);
        XFillRectangle(d, w, gc, x0 + i * aw, rowY, static_cast<unsigned>(aw), static_cast<unsigned>(rowH));
        set_color(d, gc, 0xFFFFFF);
        const auto action = actions[static_cast<std::size_t>(i)];
        const char* label = "";
        switch (action) {
            case such::ui::ResultAction::OpenLocation: label = "Location"; break;
            case such::ui::ResultAction::ToggleIndex: label = item.indexed ? "Unindex" : "Index"; break;
            case such::ui::ResultAction::TogglePin: label = item.pinned ? "Unpin" : "Pin"; break;
            case such::ui::ResultAction::OpenProperties: label = "Properties"; break;
            case such::ui::ResultAction::EditAppearance: label = "Appearance"; break;
        }
        draw_utf8(d, w, gc, x0 + i * aw + 7, rowY + rowH / 2 + 4, label);
    }
}


void draw_result(Display* d, Window w, GC gc, const such::ui::ResultItem& item, const such::ui::RectF& rf,
                 int index, UiState& state) {
    const auto& m = such::ui::compute_responsive_metrics(static_cast<float>(state.width), static_cast<float>(state.height));
    if (state.swipe.state().row == index && state.swipe.state().side != such::ui::SwipeSide::Inactive) {
        draw_action_tray(d, w, gc, rf, state.swipe.state().side, m, item);
    }
    const int offset = state.swipe.state().row == index ? static_cast<int>(std::lround(state.swipe.state().offset_dip)) : 0;
    const int x = static_cast<int>(std::lround(rf.x)) + offset;
    const int y = static_cast<int>(std::lround(rf.y));
    const int rw = static_cast<int>(std::lround(rf.width));
    const int rh = static_cast<int>(std::lround(rf.height));
    fill_round_rect(d, w, gc, x, y, rw, rh, static_cast<int>(std::lround(m.corner_radius)), kBright);
    stroke_round_rect(d, w, gc, x, y, rw, rh, static_cast<int>(std::lround(m.corner_radius)),
                      state.selected == index ? kDarkGreen : kHairline);
    set_color(d, gc, kHighlight);
    XDrawLine(d, w, gc, x + 8, y + 1, x + rw - 8, y + 1);

    const int icon = static_cast<int>(std::lround(m.file_icon));
    const int ix = x + 12;
    const int iy = y + (rh - icon) / 2;
    const auto& nativeIcon = state.icon_cache.icon_for_extension(item.extension);
    state.icon_cache.draw(d, w, gc, nativeIcon, ix, iy, icon, kBright);
    draw_badge(d, w, gc, item.extension, ix + icon + 5, iy + icon + 3);

    const int tx = ix + icon + static_cast<int>(std::lround(m.icon_gap));
    const int text_width = std::max(8, rw - (tx - x) - (item.pinned ? 34 : 18));
    set_color(d, gc, kDarkGreen);
    draw_utf8(d, w, gc, tx, y + 25, ellipsize_utf8(item.filename, text_width));
    set_color(d, gc, kPathGreen);
    draw_utf8(d, w, gc, tx, y + 43, ellipsize_utf8(item.path, std::max(8, rw - (tx - x) - 18)));
    if (item.pinned) draw_pin(d, w, gc, x + rw - 24, y + 12);
}

std::vector<such::ui::ResultItem> root_items(UiState& state) {
    std::vector<such::ui::ResultItem> out;
    for (const auto& root : state.runtime.roots()) {
        such::ui::ResultItem item;
        item.path = root;
        item.filename = std::filesystem::path(root).filename().string();
        if (item.filename.empty()) item.filename = root;
        item.indexed = true;
        out.push_back(std::move(item));
    }
    return out;
}

void refresh_query(UiState& state, bool reset_scroll = true) {
    const auto fontCommand = such::ui::parse_font_command(state.query, such::ui::PlatformDialect::UnixLike);
    const auto indexCommand = such::ui::parse_index_command(state.query, such::ui::PlatformDialect::UnixLike);
    const auto observed = state.runtime.observed_extensions();
    if (fontCommand.matched) {
        state.results.clear();
        state.suggestions.clear();
        if (fontCommand.show_picker) {
            for (const auto& option : such::ui::builtin_font_options()) {
                state.suggestions.push_back({"//font " + option.alias, option.label});
            }
            state.suggestions.push_back({"//font system", "System default"});
        }
    } else if (indexCommand.matched) {
        state.suggestions = such::ui::autocomplete(state.query, such::ui::PlatformDialect::UnixLike, observed);
        if (indexCommand.kind == such::ui::IndexCommandKind::ShowRoots) state.results = root_items(state);
        else state.results.clear();
    } else {
        state.suggestions = such::ui::autocomplete(state.query, such::ui::PlatformDialect::UnixLike, observed);
        if (state.demo) {
            state.results = such::ui::make_demo_results(state.query, such::ui::PlatformDialect::UnixLike,
                                                       static_cast<std::int64_t>(std::time(nullptr)));
        } else {
            state.results = state.runtime.search(state.query, such::ui::PlatformDialect::UnixLike);
        }
    }
    state.selected = state.results.empty() ? -1 : std::clamp(state.selected, 0, static_cast<int>(state.results.size()) - 1);
    if (reset_scroll) state.scroll_dip = 0.0f;
    const auto layout = such::ui::compute_window_layout(static_cast<float>(state.width), static_cast<float>(state.height));
    state.scroll_dip = std::clamp(state.scroll_dip, 0.0f, such::ui::max_result_scroll(layout, state.results.size()));
    state.swipe.close();
}

int hit_row(const UiState& state, int x, int y) {
    const auto layout = such::ui::compute_window_layout(static_cast<float>(state.width), static_cast<float>(state.height));
    const float xf = static_cast<float>(x);
    const float yf = static_cast<float>(y);
    const auto& viewport = layout.results_viewport;
    if (xf < viewport.x || xf >= viewport.x + viewport.width || yf < viewport.y || yf >= viewport.y + viewport.height) return -1;
    const float stride = layout.metrics.row_height + layout.metrics.row_gap;
    if (stride <= 0.0f) return -1;
    const float content_y = yf - viewport.y + state.scroll_dip;
    const int index = static_cast<int>(std::floor(content_y / stride));
    if (index < 0 || index >= static_cast<int>(state.results.size())) return -1;
    const auto row = such::ui::result_row_rect(layout, static_cast<std::size_t>(index), state.scroll_dip);
    return (yf >= row.y && yf < row.y + row.height) ? index : -1;
}

void ensure_selected_visible(UiState& state) {
    if (state.selected < 0) return;
    const auto layout = such::ui::compute_window_layout(static_cast<float>(state.width), static_cast<float>(state.height));
    const auto row = such::ui::result_row_rect(layout, static_cast<std::size_t>(state.selected), state.scroll_dip);
    if (row.y < layout.results_viewport.y) {
        state.scroll_dip = static_cast<float>(state.selected) * (layout.metrics.row_height + layout.metrics.row_gap);
    } else if (row.y + row.height > layout.results_viewport.y + layout.results_viewport.height) {
        state.scroll_dip += row.y + row.height - (layout.results_viewport.y + layout.results_viewport.height);
    }
    state.scroll_dip = std::clamp(state.scroll_dip, 0.0f, such::ui::max_result_scroll(layout, state.results.size()));
}

bool hit_swipe_action(const UiState& state, int x, int y, int& row_index, such::ui::ResultAction& action) {
    if (!state.swipe.is_open()) return false;
    row_index = state.swipe.state().row;
    if (row_index < 0 || row_index >= static_cast<int>(state.results.size())) return false;
    const auto layout = such::ui::compute_window_layout(static_cast<float>(state.width), static_cast<float>(state.height));
    const auto row = such::ui::result_row_rect(layout, static_cast<std::size_t>(row_index), state.scroll_dip);
    const float xf = static_cast<float>(x);
    const float yf = static_cast<float>(y);
    if (yf < row.y || yf >= row.y + row.height) return false;
    const float aw = layout.metrics.swipe_action_width;
    const float total = aw * 3.0f;
    const float offset = state.swipe.state().offset_dip;
    int index = -1;
    if (state.swipe.state().side == such::ui::SwipeSide::Trailing) {
        const float start = row.x + row.width - total;
        const float revealed_start = std::max(start, row.x + row.width + offset);
        if (xf >= revealed_start && xf < row.x + row.width) index = static_cast<int>((xf - start) / aw);
    } else {
        const float end = row.x + total;
        const float revealed_end = std::min(end, row.x + offset);
        if (xf >= row.x && xf < revealed_end) index = static_cast<int>((xf - row.x) / aw);
    }
    if (index < 0 || index > 2) return false;
    action = such::ui::actions_for_side(state.swipe.state().side)[static_cast<std::size_t>(index)];
    return true;
}

void open_item_linux(const such::ui::ResultItem& item) {
    if (item.path.empty()) return;
    const pid_t pid = ::fork();
    if (pid == 0) {
        ::execlp("xdg-open", "xdg-open", item.path.c_str(), static_cast<char*>(nullptr));
        _exit(127);
    }
}

void open_location_linux(const such::ui::ResultItem& item) {
    std::filesystem::path path(item.path);
    std::filesystem::path directory = path.has_parent_path() ? path.parent_path() : path;
    if (directory.empty()) return;
    const std::string dir = directory.string();
    const pid_t pid = ::fork();
    if (pid == 0) {
        ::execlp("xdg-open", "xdg-open", dir.c_str(), static_cast<char*>(nullptr));
        _exit(127);
    }
}

void perform_action(UiState& state, int row_index, such::ui::ResultAction action) {
    if (row_index < 0 || row_index >= static_cast<int>(state.results.size())) return;
    auto& item = state.results[static_cast<std::size_t>(row_index)];
    switch (action) {
        case such::ui::ResultAction::OpenLocation:
            open_location_linux(item);
            break;
        case such::ui::ResultAction::ToggleIndex:
            if (state.demo) item.indexed = !item.indexed;
            else {
                std::string error;
                (void)state.runtime.set_indexed(item.path, !item.indexed, &error);
                refresh_query(state, false);
            }
            break;
        case such::ui::ResultAction::TogglePin:
            if (state.demo) item.pinned = !item.pinned;
            else {
                std::string error;
                (void)state.runtime.set_pinned(item.path, !item.pinned, &error);
                refresh_query(state, false);
            }
            break;
        case such::ui::ResultAction::OpenProperties:
        case such::ui::ResultAction::EditAppearance:
            // No universal Linux native properties/appearance API. These are only
            // reachable when the non-canonical leading experiment is enabled.
            break;
    }
    state.swipe.close();
}

void complete_first(UiState& state) {
    if (state.suggestions.empty()) return;
    const auto pos = state.query.find_last_of(" \t\n");
    state.query = (pos == std::string::npos ? std::string{} : state.query.substr(0, pos + 1)) + state.suggestions.front().token + " ";
    refresh_query(state);
}

void draw(Display* d, Window w, GC gc, UiState& state) {
    const auto layout = such::ui::compute_window_layout(static_cast<float>(state.width), static_cast<float>(state.height));
    const auto& m = layout.metrics;
    set_color(d, gc, kPaper);
    XFillRectangle(d, w, gc, 0, 0, static_cast<unsigned>(state.width), static_cast<unsigned>(state.height));

    const auto& sr = layout.search;
    fill_round_rect(d, w, gc, static_cast<int>(sr.x), static_cast<int>(sr.y), static_cast<int>(sr.width), static_cast<int>(sr.height),
                    static_cast<int>(m.search_radius), kBright);
    stroke_round_rect(d, w, gc, static_cast<int>(sr.x), static_cast<int>(sr.y), static_cast<int>(sr.width), static_cast<int>(sr.height),
                      static_cast<int>(m.search_radius), kDarkGreen);
    set_color(d, gc, kHighlight);
    XDrawLine(d, w, gc, static_cast<int>(sr.x + 8), static_cast<int>(sr.y + 1), static_cast<int>(sr.x + sr.width - 8), static_cast<int>(sr.y + 1));
    draw_search_glyph(d, w, gc, static_cast<int>(sr.x + 20), static_cast<int>(sr.y + sr.height / 2));
    set_color(d, gc, state.query.empty() ? kPlaceholderGray : kDarkGreen);
    const std::string label = state.query.empty() ? "2026 Heritage Inc." : state.query;
    draw_utf8(d, w, gc, static_cast<int>(sr.x + 39), static_cast<int>(sr.y + sr.height / 2 + 5),
              ellipsize_utf8(label, std::max(8, static_cast<int>(sr.width) - 58)));

    const float stride = m.row_height + m.row_gap;
    const int first_row = stride > 0.0f ? std::max(0, static_cast<int>(std::floor(state.scroll_dip / stride))) : 0;
    const int last_row = std::min(static_cast<int>(state.results.size()), first_row + std::max(2, m.visible_results + 2));
    for (int i = first_row; i < last_row; ++i) {
        const auto row = such::ui::result_row_rect(layout, static_cast<std::size_t>(i), state.scroll_dip);
        if (row.y + row.height <= layout.results_viewport.y || row.y >= layout.results_viewport.y + layout.results_viewport.height) continue;
        draw_result(d, w, gc, state.results[static_cast<std::size_t>(i)], row, i, state);
    }

    if (state.demo && !state.query.empty() && state.results.empty()) {
        set_color(d, gc, kPathGreen);
        const char* no = "No matches";
        draw_utf8(d, w, gc, static_cast<int>(layout.results_viewport.x), static_cast<int>(layout.results_viewport.y + 28), no);
    }

    if (such::ui::max_result_scroll(layout, state.results.size()) > 0.0f) {
        const float max_scroll = such::ui::max_result_scroll(layout, state.results.size());
        const float content = such::ui::result_content_height(layout, state.results.size());
        const float ratio = content > 0.0f ? layout.results_viewport.height / content : 1.0f;
        const int bar_h = std::max(24, static_cast<int>(layout.results_viewport.height * ratio));
        const float travel = std::max(1.0f, layout.results_viewport.height - static_cast<float>(bar_h));
        const int bar_y = static_cast<int>(layout.results_viewport.y + travel * (state.scroll_dip / max_scroll));
        set_color(d, gc, kHairline);
        XFillRectangle(d, w, gc,
                       static_cast<int>(layout.results_viewport.x + layout.results_viewport.width - 3.0f), bar_y,
                       2u, static_cast<unsigned>(bar_h));
    }

    if (!state.suggestions.empty()) {
        const int count = std::min(6, static_cast<int>(state.suggestions.size()));
        const int itemH = 28;
        const int px0 = static_cast<int>(sr.x);
        const int py0 = static_cast<int>(sr.y + sr.height + 4);
        const int pw = static_cast<int>(sr.width);
        fill_round_rect(d, w, gc, px0, py0, pw, itemH * count, 5, kBright);
        stroke_round_rect(d, w, gc, px0, py0, pw, itemH * count, 5, kHairline);
        for (int i = 0; i < count; ++i) {
            set_color(d, gc, kDarkGreen);
            const auto& s = state.suggestions[static_cast<std::size_t>(i)];
            draw_utf8(d, w, gc, px0 + 12, py0 + i * itemH + 19, s.token);
            set_color(d, gc, kPathGreen);
            draw_utf8(d, w, gc, px0 + 120, py0 + i * itemH + 19, s.label);
        }
    }
}


bool recreate_font_set(Display* d, std::string_view family) {
    if (gFontSet) {
        XFreeFontSet(d, gFontSet);
        gFontSet = nullptr;
    }
    std::vector<std::string> candidates;
    if (!family.empty()) {
        candidates.emplace_back(family);
        std::string xlfd = "-*-";
        for (char c : family) xlfd.push_back(c == ' ' ? '*' : c);
        xlfd += "-medium-r-normal--14-*-*-*-*-*-*-*";
        candidates.push_back(std::move(xlfd));
    }
    candidates.emplace_back("-*-*-medium-r-normal--14-*-*-*-*-*-*-*");
    for (const auto& pattern : candidates) {
        char** missing = nullptr;
        int missingCount = 0;
        char* defaultString = nullptr;
        gFontSet = XCreateFontSet(d, pattern.c_str(), &missing, &missingCount, &defaultString);
        if (missing) XFreeStringList(missing);
        if (gFontSet) return true;
    }
    return false;
}

bool execute_font_command_linux(Display* d, UiState& state) {
    const auto cmd = such::ui::parse_font_command(state.query, such::ui::PlatformDialect::UnixLike);
    if (!cmd.matched || cmd.show_picker || !cmd.requested_family.has_value()) return false;
    state.font_family = *cmd.requested_family;
    std::string error;
    const bool saved = state.font_family.empty() ? such::ui::clear_font_preference(&error)
                                                 : such::ui::save_font_preference(state.font_family, &error);
    if (!saved) std::fprintf(stderr, "Such: could not save font preference: %s\n", error.c_str());
    (void)recreate_font_set(d, state.font_family);
    state.query.clear();
    refresh_query(state);
    return true;
}


bool execute_index_command_linux(UiState& state) {
    const auto command = such::ui::parse_index_command(state.query, such::ui::PlatformDialect::UnixLike);
    if (!command.matched) return false;
    std::string error;
    switch (command.kind) {
        case such::ui::IndexCommandKind::AddRoot:
            if (!command.argument.has_value()) {
                state.suggestions = {{"//index /path/to/folder", "Type a folder path after //index"}};
                return true;
            }
            (void)state.runtime.add_root(*command.argument, &error);
            state.query.clear();
            state.results.clear();
            state.suggestions.clear();
            state.scroll_dip = 0.0f;
            return true;
        case such::ui::IndexCommandKind::ReplaceRoot:
            if (!command.argument.has_value()) {
                state.suggestions = {{"//drive /path/to/folder", "Replace all search roots with one folder"}};
                return true;
            }
            (void)state.runtime.replace_roots({std::filesystem::path(*command.argument)}, &error);
            state.query.clear();
            state.results.clear();
            state.suggestions.clear();
            state.scroll_dip = 0.0f;
            return true;
        case such::ui::IndexCommandKind::Reindex:
            state.runtime.reindex_async();
            state.query.clear();
            state.results.clear();
            state.suggestions.clear();
            state.scroll_dip = 0.0f;
            return true;
        case such::ui::IndexCommandKind::ShowRoots:
            refresh_query(state);
            return true;
        case such::ui::IndexCommandKind::NoCommand:
            return false;
    }
    return false;
}

} // namespace

int main(int argc, char** argv) {
    std::signal(SIGCHLD, SIG_IGN);
    UiState state;
    for (int i = 1; i < argc; ++i) {
        if (std::strcmp(argv[i], "--smoke") == 0) state.smoke = true;
        if (std::strcmp(argv[i], "--demo") == 0) state.demo = true;
    }
    if (state.demo) refresh_query(state);

    auto lease = such::ui::FrontendLease::try_acquire(such::ui::FrontendMode::Gui);
    if (!lease.acquired()) {
        std::fprintf(stderr, "Such GUI unavailable: %s\n", lease.error().c_str());
        return 23;
    }

    std::string runtime_error;
    if (!state.runtime.load(&runtime_error)) std::fprintf(stderr, "Such: index load failed: %s\n", runtime_error.c_str());
    state.runtime_generation = state.runtime.generation();
    if (!state.demo) {
        const auto status = state.runtime.status();
        if (status.indexed_files == 0 && !status.roots.empty()) state.runtime.reindex_async();
    }

    Display* d = XOpenDisplay(nullptr);
    if (!d) {
        std::fprintf(stderr, "Such: XOpenDisplay failed\n");
        return 2;
    }
    std::setlocale(LC_CTYPE, "");
    XSetLocaleModifiers("");
    if (const auto preferred = such::ui::load_font_preference(); preferred) state.font_family = *preferred;
    (void)recreate_font_set(d, state.font_family);

    const int screen = DefaultScreen(d);
    Window w = XCreateSimpleWindow(d, RootWindow(d, screen), 60, 60, static_cast<unsigned>(state.width), static_cast<unsigned>(state.height),
                                   1, kDarkGreen, kPaper);
    XStoreName(d, w, "Such v0.6.2");
    XSizeHints hints{};
    hints.flags = PMinSize;
    hints.min_width = 420;
    hints.min_height = 390;
    XSetWMNormalHints(d, w, &hints);
    XSelectInput(d, w, ExposureMask | StructureNotifyMask | KeyPressMask | ButtonPressMask | ButtonReleaseMask | PointerMotionMask | FocusChangeMask);
    Atom wmDelete = XInternAtom(d, "WM_DELETE_WINDOW", False);
    XSetWMProtocols(d, w, &wmDelete, 1);
    gInputMethod = XOpenIM(d, nullptr, nullptr, nullptr);
    if (gInputMethod) {
        gInputContext = XCreateIC(gInputMethod,
            XNInputStyle, XIMPreeditNothing | XIMStatusNothing,
            XNClientWindow, w,
            XNFocusWindow, w,
            nullptr);
        // XIC retains its XIM relationship. It is destroyed before the display closes.
    }
    XMapWindow(d, w);
    GC gc = XCreateGC(d, w, 0, nullptr);

    bool running = true;
    int exposes = 0;
    while (running) {
        XEvent e{};
        XNextEvent(d, &e);
        switch (e.type) {
            case ConfigureNotify:
                state.width = e.xconfigure.width;
                state.height = e.xconfigure.height;
                state.swipe.close();
                draw(d, w, gc, state);
                break;
            case Expose:
                if (e.xexpose.count == 0) {
                    draw(d, w, gc, state);
                    if (state.smoke && ++exposes >= 1) running = false;
                }
                break;
            case KeyPress: {
                char buf[256]{};
                KeySym ks{};
                int n = 0;
                if (gInputContext) {
                    Status status{};
                    n = Xutf8LookupString(gInputContext, &e.xkey, buf, static_cast<int>(sizeof(buf) - 1), &ks, &status);
                    if (n < 0) n = 0;
                } else {
                    n = XLookupString(&e.xkey, buf, static_cast<int>(sizeof(buf) - 1), &ks, nullptr);
                }
                if (ks == XK_Escape) {
                    if (state.swipe.is_open() || !state.suggestions.empty()) {
                        state.swipe.close();
                        state.suggestions.clear();
                    } else {
                        running = false;
                    }
                } else if (ks == XK_BackSpace && !state.query.empty()) {
                    // XIM returns UTF-8. Delete one code point rather than one byte so
                    // Korean/CJK input cannot leave an invalid query buffer.
                    pop_utf8_codepoint(state.query);
                    refresh_query(state);
                } else if (ks == XK_Tab) {
                    complete_first(state);
                } else if (ks == XK_Down && !state.results.empty()) {
                    state.selected = std::min(state.selected + 1, static_cast<int>(state.results.size()) - 1);
                    ensure_selected_visible(state);
                } else if (ks == XK_Up && !state.results.empty()) {
                    state.selected = state.selected <= 0 ? 0 : state.selected - 1;
                    ensure_selected_visible(state);
                } else if ((ks == XK_Return || ks == XK_KP_Enter) && execute_font_command_linux(d, state)) {
                    // Hidden //font command consumed.
                } else if ((ks == XK_Return || ks == XK_KP_Enter) && execute_index_command_linux(state)) {
                    // Hidden //index / //reindex / //roots command consumed.
                } else if ((ks == XK_Return || ks == XK_KP_Enter) &&
                           state.selected >= 0 && state.selected < static_cast<int>(state.results.size())) {
                    open_item_linux(state.results[static_cast<std::size_t>(state.selected)]);
                } else if ((e.xkey.state & Mod1Mask) != 0 &&
                           state.selected >= 0 && state.selected < static_cast<int>(state.results.size()) &&
                           (ks == XK_l || ks == XK_L)) {
                    perform_action(state, state.selected, such::ui::ResultAction::OpenLocation);
                } else if ((e.xkey.state & Mod1Mask) != 0 &&
                           state.selected >= 0 && state.selected < static_cast<int>(state.results.size()) &&
                           (ks == XK_i || ks == XK_I)) {
                    perform_action(state, state.selected, such::ui::ResultAction::ToggleIndex);
                } else if ((e.xkey.state & Mod1Mask) != 0 &&
                           state.selected >= 0 && state.selected < static_cast<int>(state.results.size()) &&
                           (ks == XK_p || ks == XK_P)) {
                    perform_action(state, state.selected, such::ui::ResultAction::TogglePin);
                } else if (n > 0 && static_cast<unsigned char>(buf[0]) >= 0x20) {
                    state.query.append(buf, buf + n);
                    refresh_query(state);
                }
                draw(d, w, gc, state);
                break;
            }
            case ButtonPress: {
                if (e.xbutton.button == Button4 || e.xbutton.button == Button5) {
                    const auto layout = such::ui::compute_window_layout(static_cast<float>(state.width), static_cast<float>(state.height));
                    const float step = (layout.metrics.row_height + layout.metrics.row_gap) * 2.5f;
                    state.scroll_dip += e.xbutton.button == Button4 ? -step : step;
                    state.scroll_dip = std::clamp(state.scroll_dip, 0.0f, such::ui::max_result_scroll(layout, state.results.size()));
                    state.swipe.close();
                    draw(d, w, gc, state);
                    break;
                }
                if (e.xbutton.button != Button1) break;
                int action_row = -1;
                such::ui::ResultAction action{};
                if (hit_swipe_action(state, e.xbutton.x, e.xbutton.y, action_row, action)) {
                    perform_action(state, action_row, action);
                    draw(d, w, gc, state);
                    break;
                }
                const int row = hit_row(state, e.xbutton.x, e.xbutton.y);
                if (row >= 0) {
                    state.selected = row;
                    state.swipe.set_action_tray_width(such::ui::compute_responsive_metrics(
                        static_cast<float>(state.width), static_cast<float>(state.height)).swipe_action_width * 3.0f);
                    state.swipe.begin(row, static_cast<float>(e.xbutton.x), static_cast<float>(e.xbutton.y));
                    state.last_motion = std::chrono::steady_clock::now();
                } else {
                    state.swipe.close();
                }
                draw(d, w, gc, state);
                break;
            }
            case MotionNotify: {
                if (!state.swipe.state().dragging) break;
                const auto now = std::chrono::steady_clock::now();
                const float dt = std::max(0.001f, std::chrono::duration<float>(now - state.last_motion).count());
                state.last_motion = now;
                state.swipe.update(static_cast<float>(e.xmotion.x), static_cast<float>(e.xmotion.y), dt);
                draw(d, w, gc, state);
                break;
            }
            case ButtonRelease: {
                if (e.xbutton.button != Button1 || !state.swipe.state().dragging) break;
                const int row = state.swipe.state().row;
                if (const auto action = state.swipe.end(static_cast<float>(state.width))) {
                    perform_action(state, row, *action);
                }
                draw(d, w, gc, state);
                break;
            }
            case FocusIn:
                if (gInputContext) XSetICFocus(gInputContext);
                break;
            case FocusOut:
                if (gInputContext) XUnsetICFocus(gInputContext);
                state.swipe.close();
                break;
            case ClientMessage:
                if (static_cast<Atom>(e.xclient.data.l[0]) == wmDelete) running = false;
                break;
            default:
                break;
        }
    }

    if (gInputContext) { XDestroyIC(gInputContext); gInputContext = nullptr; }
    if (gInputMethod) { XCloseIM(gInputMethod); gInputMethod = nullptr; }
    if (gFontSet) { XFreeFontSet(d, gFontSet); gFontSet = nullptr; }
    XFreeGC(d, gc);
    XDestroyWindow(d, w);
    XCloseDisplay(d);
    return 0;
}
