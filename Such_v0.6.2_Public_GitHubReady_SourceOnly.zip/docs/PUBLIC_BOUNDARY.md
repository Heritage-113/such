# Public repository boundary

This repository is intentionally limited to frontend code and the stable runtime client ABI.

The proprietary storage/search implementation, its third-party dependencies, its benchmarks, its validation data, and its build machinery are maintained in a physically separate private working tree. They are not hidden with ignore rules inside this repository.

Public builds use an ABI stub for contract tests. Production builds discover the separately installed runtime shared library at process startup. `SUCH_RUNTIME_LIBRARY` may be used by developers to point the client at a specific runtime binary.
