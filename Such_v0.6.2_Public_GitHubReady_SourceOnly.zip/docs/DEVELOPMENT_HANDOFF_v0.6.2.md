# Such v0.6.2 Public Handoff

## Repository role

This is the GitHub-safe Such repository. It owns UI, CLI, query syntax, gestures, icons/fonts, installers, the stable C runtime ABI, and `RuntimeClient`.

It does not own the production search/storage implementation.

## Runtime boundary

`RuntimeClient` dynamically loads:

- Windows: `SuchRuntimePrivate.dll`
- Linux: `libSuchRuntimePrivate.so`
- macOS: `libSuchRuntimePrivate.dylib`

`SUCH_RUNTIME_LIBRARY` overrides discovery for development/testing.

ABI version: 1. The ABI header hash used by all three repositories is recorded in the release notes.

## Search root commands

- Windows `/index` adds a root; `/drive` replaces all roots.
- Unix-like `//index` adds a root; `//drive` replaces all roots.

## Publication rule

Publish this tree itself. Never create the public repository by copying the private runtime tree and relying on ignore rules.
